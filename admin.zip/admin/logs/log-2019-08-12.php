<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-12 09:38:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:38:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:38:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:38:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:39:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:40:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:34 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2019-08-12 09:44:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:44:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 09:46:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 09:46:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:46:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:47:40 --> 404 Page Not Found: Dashboard/index
ERROR - 2019-08-12 09:47:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:47:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:47:57 --> 404 Page Not Found: Dashboard/index
ERROR - 2019-08-12 09:47:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:47:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(header.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'header.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:48:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:42 --> 404 Page Not Found: Dashboard/dashboard
ERROR - 2019-08-12 09:49:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(header.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'header.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 09:49:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(header.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'header.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 1
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 3
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:22:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:25:28 --> Severity: error --> Exception: Call to undefined method CI_Loader::include() C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 2
ERROR - 2019-08-12 10:25:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:25:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:25:29 --> Severity: error --> Exception: Call to undefined method CI_Loader::include() C:\xampps\htdocs\payroll\admin\application\views\dashboard\dashboard.php 2
ERROR - 2019-08-12 10:25:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:25:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:30:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:03 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2019-08-12 10:31:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:11 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2019-08-12 10:31:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:15 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2019-08-12 10:31:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:31:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:12 --> 404 Page Not Found: Clientsphp/index
ERROR - 2019-08-12 10:32:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:32:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:32:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:33:13 --> 404 Page Not Found: Forgot-passwordphp/index
ERROR - 2019-08-12 10:33:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:33:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:35:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:37:22 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:37:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:37:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:37:22 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:37:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:37:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:49 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:38:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:38:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:38:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:39:12 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:39:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:41 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:39:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:42 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:39:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:43 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:39:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:39:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:40:52 --> Severity: error --> Exception: syntax error, unexpected 'l' (T_STRING) C:\xampps\htdocs\payroll\admin\application\views\common\login.php 57
ERROR - 2019-08-12 10:40:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:40:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 10:41:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:41:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:42:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:17 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:43:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:17 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:43:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:43:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:21 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:44:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:34 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:44:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:44:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:45:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:45:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:10 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:46:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:10 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 10:46:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:39 --> 404 Page Not Found: Dashboard/dashboard
ERROR - 2019-08-12 10:46:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:46:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:48:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:54:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:55:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:57:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:57:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 10:59:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:59 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:00:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:00:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:02:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:03:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:05:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:08:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:09:53 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampps\htdocs\payroll\admin\application\views\common\header.php 307
ERROR - 2019-08-12 11:09:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:09:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:10:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:11:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:13:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:16:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:18:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:19:42 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 11:19:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:19:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:20:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:22:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:24:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 11:24:50 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:24:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:25:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:26:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:26:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:26:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:26:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:27:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:28:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:29:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:29:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:29:58 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 34
ERROR - 2019-08-12 11:29:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:29:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:30:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:14 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 34
ERROR - 2019-08-12 11:30:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:30:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:30:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:30:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:32:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:32:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:32:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:32:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:39:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:39:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> 404 Page Not Found: Upload/UserProfile7.jpg
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:13 --> 404 Page Not Found: Upload/UserProfile7.jpg
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:39:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:40:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:40:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:40:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:40:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:40:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:40:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:42:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:43:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:43:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:44:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:44:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:02 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:46:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:46:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:50:53 --> Severity: error --> Exception: Call to undefined function check_user_authentication() C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 59
ERROR - 2019-08-12 11:50:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:50:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 11:51:24 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:51:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:51:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:51:26 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:51:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:51:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:51:59 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:51:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:51:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:52:50 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:52:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:52:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:55:28 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:55:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:55:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:56:22 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:56:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:56:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:56:36 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 11:56:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 11:56:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:08:49 --> Severity: Notice --> Use of undefined constant EMAIL_NOT_FOUND - assumed 'EMAIL_NOT_FOUND' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 68
ERROR - 2019-08-12 12:08:49 --> Severity: Notice --> Use of undefined constant EMAIL_NOT_FOUND - assumed 'EMAIL_NOT_FOUND' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 69
ERROR - 2019-08-12 12:08:49 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:08:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:08:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:08:49 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:08:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:08:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:32 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:09:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:37 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:09:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:42 --> Severity: Notice --> Use of undefined constant EMAIL_NOT_FOUND - assumed 'EMAIL_NOT_FOUND' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 78
ERROR - 2019-08-12 12:09:42 --> Severity: Notice --> Use of undefined constant EMAIL_NOT_FOUND - assumed 'EMAIL_NOT_FOUND' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 79
ERROR - 2019-08-12 12:09:42 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:09:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:09:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:28 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:13:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:30 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:13:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:34 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:13:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:41 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = 'Yx503'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:13:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:55 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:13:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:59 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = 'JgGcE'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:13:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:13:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:16:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:16:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:16:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:16:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:43 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:18:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:43 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:18:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:18:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:19:10 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:19:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:19:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:19:14 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = 'oepZT'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:19:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:19:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:25:41 --> Severity: Notice --> Undefined index: EmailAddress C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 14
ERROR - 2019-08-12 12:26:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 12:26:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:26:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:27:19 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:27:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:27:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:27:20 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:27:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:27:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:25 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:28:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:28 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:30 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:28:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:40 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = 'W1ELf'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:28:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:28:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:29:59 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = '6zXyi'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:29:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:29:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:31:46 --> Query error: Unknown column 'PasswordResetCode' in 'field list' - Invalid query: UPDATE `tbluser` SET `PasswordResetCode` = '0mgTO'
WHERE `UserId` = '1'
ERROR - 2019-08-12 12:31:46 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:31:46 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:33:33 --> Severity: Notice --> Undefined property: stdClass::$UserName C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 46
ERROR - 2019-08-12 12:33:33 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:33:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:33:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:34:06 --> Severity: Notice --> Undefined property: stdClass::$UserName C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 46
ERROR - 2019-08-12 12:34:43 --> Severity: Notice --> Undefined property: stdClass::$UserName C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 46
ERROR - 2019-08-12 12:34:43 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:34:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:34:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:36:30 --> Severity: Notice --> Undefined variable: username C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 62
ERROR - 2019-08-12 12:36:30 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:36:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:36:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:36:45 --> Severity: Notice --> Undefined variable: username C:\xampps\htdocs\payroll\admin\application\models\Login_model.php 62
ERROR - 2019-08-12 12:36:45 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:36:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:36:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:37:25 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:37:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:37:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:42 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:38:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:45 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:38:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:57 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:38:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:38:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:12 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:41:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:14 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:41:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:19 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:41:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:31 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:41:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:41:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:42:31 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 12:42:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:42:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:45 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:43:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:47 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:43:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:51 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:43:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:53 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:43:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:57 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:43:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:43:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:02 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:49 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:44:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:52 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:44:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:44:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:26 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:45:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:43 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:45:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:49 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:45:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:45:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:29 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:46:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:30 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:46:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:37 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:46:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:42 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:46:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:46:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:56 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:47:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:58 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:47:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:59 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:47:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:47:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:01 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:48:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:35 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:48:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:38 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:48:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:48:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:49:25 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:49:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:49:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:49:28 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:49:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:49:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:00 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:56:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:01 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:56:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:06 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:56:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:09 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:56:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:11 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:56:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:56:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:16 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:57:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:18 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:57:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:22 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 12:57:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:57:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:35 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:58:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:57 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:58:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:59 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:58:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:58:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:59:06 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 12:59:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 12:59:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:25 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:02:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:27 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:02:27 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:27 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:30 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:02:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:02:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:12 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:15 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:29 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:30 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:33 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:49 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:07:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:54 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:07:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:07:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:02 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 13:09:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:08 --> 404 Page Not Found: Login/reset_password
ERROR - 2019-08-12 13:09:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:17 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:09:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:17 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:09:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:20 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 13:09:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:09:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:10:47 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 13:10:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:10:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:10:58 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:10:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:10:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:15 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:11:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:46 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:11:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:57 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:11:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:11:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:12:14 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:12:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:12:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:12:30 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:12:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:12:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:14:40 --> Query error: Table 'payrolldb.email_setting' doesn't exist - Invalid query: SELECT *
FROM `email_setting`
WHERE `email_setting_id` = 1
ERROR - 2019-08-12 13:14:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:14:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_db.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:16:10 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:16:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:16:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:17:33 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:17:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:17:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:17:38 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 13:17:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:17:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:18:47 --> 404 Page Not Found: Login/%7Bimage_url%7D
ERROR - 2019-08-12 13:18:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:18:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:45 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-12 13:22:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:48 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:22:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:23:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:31:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:35:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:35:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:35:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:37:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:38:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:19 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:41 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:42 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:42 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:40:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:40:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:58 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:58 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:58 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:42:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:42:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:19 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:19 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:19 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:43:19 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 13:43:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 13:43:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-12 13:43:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 13:43:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:43:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:44:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 13:45:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-12 13:45:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-12 13:45:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:21 --> 404 Page Not Found: Default/css
ERROR - 2019-08-12 13:45:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:45:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:46:53 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:46:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:47:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:55 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 13
ERROR - 2019-08-12 13:55:59 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 13
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:55:59 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:55:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 13
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:25 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:57:32 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:57:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 13:58:26 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 13:58:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 19
ERROR - 2019-08-12 14:02:50 --> Severity: Notice --> Use of undefined constant FirstName - assumed 'FirstName' C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 32
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:02:50 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:02:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 19
ERROR - 2019-08-12 14:03:21 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 32
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:21 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 19
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:52 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:03:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:36 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 19
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:04:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 19
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:05:36 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:05:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:06:49 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:06:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:06:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:10:37 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:10:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:10:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:11:11 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:11:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:11:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:11:25 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:11:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:11:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:11:36 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 33
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:51 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:11:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:12:13 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:12:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:00 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:01 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:01 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:14:01 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:14:11 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:14:54 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:14:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:14:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:11 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:15:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:31 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:15:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:35 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-12 14:15:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-12 14:15:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-12 14:15:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
