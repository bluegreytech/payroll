<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-06 06:03:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:03:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:03:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:03:50 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:03:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:03:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:03:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 06:04:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:04:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:04:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:04:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:04:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:04:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:04:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:04:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:04:22 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:04:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:04:24 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:04:24 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:04:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:04:24 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:04:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:06:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:06:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:07:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:07:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:08:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:08:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:08:44 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:08:44 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:08:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:09:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:09:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:09:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:09:31 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:12:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:12:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:12:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:12:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:13:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:13:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:13:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:13:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:13:08 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:13:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:13:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:13:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:13:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:13:10 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:15:15 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-09-06 06:15:29 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:15:29 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:15:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:15:29 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:15:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:15:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:15:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:15:31 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:16:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:16:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:16:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:16:17 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:16:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 108
ERROR - 2019-09-06 06:16:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 100
ERROR - 2019-09-06 06:16:17 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:16:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:17:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:17:34 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:18:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:18:00 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:24:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:24:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:24:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:24:44 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:25:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:25:20 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:26:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:26:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:26:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:26:39 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:27:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:27:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:27:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:27:58 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:27:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:27:59 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:01 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:29:14 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:29:16 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:29:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:29:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:52 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:29:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:30:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:30:53 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:31:06 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:31:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:31:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:31:18 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:31:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:31:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:33:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:33:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:33:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:33:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:33:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:33:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:33:33 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:33:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:37:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:37:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:37:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:38:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:38:16 --> 404 Page Not Found: Compliance/index
ERROR - 2019-09-06 06:38:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:40:51 --> Severity: Notice --> Undefined variable: complianceData C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 55
ERROR - 2019-09-06 06:40:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 55
ERROR - 2019-09-06 06:40:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:42:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:42:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:43:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:43:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:43:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:44:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:46:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:46:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:46:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:46:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:47:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:47:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 06:49:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:49:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:45 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:51:45 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:51:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:45 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:51:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:51:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:54:28 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:54:28 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:54:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:54:28 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:54:43 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:54:43 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:54:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:54:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:56:06 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:56:06 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:56:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:56:06 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:56:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:56:09 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:56:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:56:23 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:56:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:56:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:57:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:57:00 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:57:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:57:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:57:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:57:12 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:57:14 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 06:57:14 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 06:57:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:57:14 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:57:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:57:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 06:58:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:59:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 06:59:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:00:23 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 07:00:23 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 07:00:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:00:23 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 07:04:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:04:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:04:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:04:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:05:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:05:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:05:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:05:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:06:13 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:06:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:08:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:08:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:13 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:10:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:10:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:10:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:11:53 --> Query error: Column 'isdelete' in where clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
WHERE `isdelete` != 1
ORDER BY `companyid` DESC
ERROR - 2019-09-06 07:12:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:12:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:12:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:13:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:14:13 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:14:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:14:49 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 07:14:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:14:49 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 07:15:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:15:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:15:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:15:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:16:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:17:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:17:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:17:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:18:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:18:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:20:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:08:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:08:20 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:08:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:08:30 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:08:33 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:08:33 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:08:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:08:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:08:43 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:08:43 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:13:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 11:13:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:13:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:17 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:13:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:13:19 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:13:19 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:13:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:13:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 11:13:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:13:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:13:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:14:08 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:14:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:14:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 11:14:30 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 50
ERROR - 2019-09-06 11:16:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 11:16:04 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 50
ERROR - 2019-09-06 11:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 11:16:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:16:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:16:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:16:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:16:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:17:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:17:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:17:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:17:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:17:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 11:17:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:17:09 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:17:13 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:17:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:17:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:17:55 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:17:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:18:04 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:18:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:00 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:19 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:31 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:50 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:19:53 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 11:19:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:20:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:20:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:20:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:20:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:21:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:21:54 --> 404 Page Not Found: Compliance/index
ERROR - 2019-09-06 11:21:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:21:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:22:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:22:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:23:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:23:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:23:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:25:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:26:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:27:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:28:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:28:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:29:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:29:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:29:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:30:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:30:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:30:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:31:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:31:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:31:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:32:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:32:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:33:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:39:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:39:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:39:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:41:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:42:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:42:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:42:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:42:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:42:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:43:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:43:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:43:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:44:10 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:44:10 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:44:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:45:45 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:45:45 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:45:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:47:15 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:47:15 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:47:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:47:35 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:47:35 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:47:35 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:48:47 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:48:47 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:48:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:49:01 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:49:01 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:49:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:51:51 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 11:51:51 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:51:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:53:50 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 310
ERROR - 2019-09-06 11:53:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:54:13 --> Query error: Table 'payrolldb.tbluser' doesn't exist - Invalid query: SELECT *
FROM `tbluser`
WHERE `EmailAddress` = 'bluegreyindia@gmail.com'
ERROR - 2019-09-06 11:55:36 --> Query error: Column 'Contact' cannot be null - Invalid query: INSERT INTO `tblhr` (`hr_type`, `FullName`, `EmailAddress`, `Password`, `Address`, `Contact`, `DateofBirth`, `City`, `PinCode`, `Gender`, `IsActive`, `CreatedOn`) VALUES (1, 'mitesh patel', 'bluegreyindia@gmail.com', '05b909ad5767b1ca6de513151a5d17b8', 'Vadodara', NULL, '2019-09-30', 'Vadodra', '111111', 'Male', '1', '2019-09-06')
ERROR - 2019-09-06 11:57:59 --> Query error: Column 'Contact' cannot be null - Invalid query: INSERT INTO `tblhr` (`hr_type`, `FullName`, `EmailAddress`, `Password`, `Address`, `Contact`, `DateofBirth`, `City`, `PinCode`, `Gender`, `IsActive`, `CreatedOn`) VALUES (1, 'mitesh patel', 'bluegreyindia@gmail.com', '52cde3b797723acf97196a49b65f9729', 'Vadodara', NULL, '2019-09-30', 'Vadodra', '111111', 'Male', '1', '2019-09-06')
ERROR - 2019-09-06 11:58:01 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 309
ERROR - 2019-09-06 11:58:45 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 309
ERROR - 2019-09-06 11:58:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 11:58:56 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 309
ERROR - 2019-09-06 11:58:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:00:08 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 309
ERROR - 2019-09-06 12:00:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:01:16 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 309
ERROR - 2019-09-06 12:01:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:02:42 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 352
ERROR - 2019-09-06 12:02:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:03:32 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 354
ERROR - 2019-09-06 12:03:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:03:57 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 356
ERROR - 2019-09-06 12:03:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:04:15 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 356
ERROR - 2019-09-06 12:04:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:05:47 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:05:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:05:56 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:05:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:06:18 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:06:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:07:38 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:07:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:07:43 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:07:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:07:56 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:07:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:08:11 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:08:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:09:21 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 321
ERROR - 2019-09-06 12:09:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:09:53 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 318
ERROR - 2019-09-06 12:09:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:12:07 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 315
ERROR - 2019-09-06 12:12:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:12:27 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 315
ERROR - 2019-09-06 12:12:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:13:46 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 315
ERROR - 2019-09-06 12:13:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:14:31 --> Severity: Notice --> Undefined variable: companytypeData C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 315
ERROR - 2019-09-06 12:14:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:15:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:17:00 --> Severity: Notice --> Undefined variable: Gender C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 357
ERROR - 2019-09-06 12:17:00 --> Severity: Notice --> Undefined variable: Gender C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 364
ERROR - 2019-09-06 12:17:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:18:28 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 346
ERROR - 2019-09-06 12:18:51 --> Severity: Notice --> Undefined variable: Gender C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 346
ERROR - 2019-09-06 12:18:51 --> Severity: Notice --> Undefined variable: Gender C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 347
ERROR - 2019-09-06 12:18:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:19:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:20:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:20:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:21:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:21:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:21:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:25:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:25:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:25:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:27:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:27:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:28:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:28:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:30:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:30:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:30:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:30:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:31:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:31:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:31:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:31:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:31:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:32:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:33:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:33:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:34:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:34:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:36:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:36:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:36:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:36:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:36:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:38:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:39:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:39:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:39:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:39:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:39:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:40:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:40:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:40:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:41:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:41:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:41:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:41:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:41:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:42:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:42:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:42:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:42:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:42:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:42:46 --> Query error: Unknown column 't1.IsDelete' in 'where clause' - Invalid query: SELECT *
FROM `tblcompany`
WHERE `t1`.`IsDelete` != 1
ERROR - 2019-09-06 12:43:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:43:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:43:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:43:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:43:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:44:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:44:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:46:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:46:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:46:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:46:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:46:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:47:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:47:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:47:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:47:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:47:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:48:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:48:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:48:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:48:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:48:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:49:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:49:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:49:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:49:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:49:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:49:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:49:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:49:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:49:46 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:49:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:50:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 12:50:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:50:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:50:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 12:50:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:50:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 12:50:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:50:39 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:50:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:51:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:51:30 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:51:51 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:51:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:52:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:53:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:53:01 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:55:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:55:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:56:02 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:56:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:56:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:56:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:58:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:58:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 12:59:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 12:59:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 13:04:24 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\admin\application\helpers\custom_helper.php 122
ERROR - 2019-09-06 13:04:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:04:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:04:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:04:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 13:05:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:05:14 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 13:06:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:06:21 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 57
ERROR - 2019-09-06 13:06:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:06:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:06:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:06:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:06:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:06:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:07:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:07:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:07:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:07:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:07:29 --> Severity: error --> Exception: Too few arguments to function Adminmaster::change_password(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Adminmaster.php 181
ERROR - 2019-09-06 13:08:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:08:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:08:11 --> Severity: error --> Exception: Too few arguments to function Adminmaster::change_password(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Adminmaster.php 181
ERROR - 2019-09-06 13:09:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:09:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:09:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:09:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:10:07 --> Severity: error --> Exception: Too few arguments to function Adminmaster::change_password(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Adminmaster.php 181
ERROR - 2019-09-06 13:11:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:11:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:11:42 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:11:42 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:11:43 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:11:43 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:11:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:11:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:12:23 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:12:23 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:12:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:12:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:12:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:12:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:12:59 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:12:59 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:12:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:12:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:14:34 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:14:34 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:14:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:14:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:14:35 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:14:35 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:14:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:14:35 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:14:35 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:14:35 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:14:35 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:14:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:15:59 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:15:59 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:15:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:15:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:16:28 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:16:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:16:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:17:08 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:17:08 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:17:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:17:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:17:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:17:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:17:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:17:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:17:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:25:44 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\reset_password.php 65
ERROR - 2019-09-06 13:25:44 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\payroll\admin\application\views\common\reset_password.php 65
ERROR - 2019-09-06 13:27:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:27:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:27:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:27:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:27:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:27:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:27:06 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:27:06 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:27:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:27:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:28:49 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:28:49 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:28:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:28:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:28:50 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 25
ERROR - 2019-09-06 13:28:50 --> Severity: Notice --> Undefined variable: AdminId C:\xampp\htdocs\payroll\admin\application\views\common\changepassword.php 28
ERROR - 2019-09-06 13:28:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:28:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:30:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-06 13:30:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:30:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:30:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:30:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:30:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:30:59 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 13:30:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:31:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:32:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:32:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:34:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:38:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:38:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:39:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:39:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:41:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:42:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:42:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:42:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:43:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:43:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:43:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:44:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:48:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:49:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:49:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:49:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:49:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:49:54 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-06 13:51:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:51:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:52:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:52:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:52:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:53:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:53:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:53:33 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 295
ERROR - 2019-09-06 13:53:34 --> Query error: Column 'complianceid' cannot be null - Invalid query: INSERT INTO `tblcompanycompliances` (`companyid`, `complianceid`, `isactive`, `createdby`, `createdon`) VALUES (2, NULL, '1', 1, '2019-09-06 01:53:34')
ERROR - 2019-09-06 13:53:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:53:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:11 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:54:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:55:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:55:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:55:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:56:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:56:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:56:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:56:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:57:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:57:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:57:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:58:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:58:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:58:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:59:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:59:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:59:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:59:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:59:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:59:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 13:59:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 13:59:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:00:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:01:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:01:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:02:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:02:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:02:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:02:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:03:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:03:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:04:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:05:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:06:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:06:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:06:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:06:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:07:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:09:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:19 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 158
ERROR - 2019-09-06 14:09:19 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 473
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:19 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:39 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 158
ERROR - 2019-09-06 14:09:39 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 473
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:39 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:09:40 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:40 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:40 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:40 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:09:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:10:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:12:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:12:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:12:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:13:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:14:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:15:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:16:17 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:16:45 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:17:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:17:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:17:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:17:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:18:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:19:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:20:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:20:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:21:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:21:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:22:50 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 158
ERROR - 2019-09-06 14:22:50 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 473
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:22:50 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-06 14:23:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:32 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 14:23:45 --> 404 Page Not Found: Uploads/default
