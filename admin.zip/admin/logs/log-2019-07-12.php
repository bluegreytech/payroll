<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-12 13:27:15 --> 404 Page Not Found: Admin/index
ERROR - 2019-07-12 13:27:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 13:27:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 13:27:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 13:27:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 13:27:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 13:27:28 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-07-12 13:27:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 13:27:33 --> 404 Page Not Found: Stream/app-assets
