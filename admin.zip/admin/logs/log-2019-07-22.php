<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-22 11:26:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-22 11:26:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-22 11:26:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:26:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:26:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:26:41 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-07-22 11:26:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:26:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:26:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:26:45 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 11:40:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:40:26 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:40:26 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:40:26 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 11:41:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:41:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:41:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:41:10 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 11:56:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:56:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:56:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 11:56:04 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'BlogId' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 26
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 26
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'FirstName' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 27
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 27
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'UserImage' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 28
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 28
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'BlogTitle' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 29
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 29
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'BlogImage' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 30
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 30
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'BlogDescription' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 31
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 31
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'IsActive' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 32
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 32
ERROR - 2019-07-22 11:56:05 --> Severity: Warning --> Illegal string offset 'statusBlog' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 54
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Array to string conversion C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 54
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 38
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 41
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: UserImage C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 46
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: BlogTitle C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 59
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: BlogDescription C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 66
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: IsActive C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 82
ERROR - 2019-07-22 11:56:05 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 126
ERROR - 2019-07-22 11:56:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'BlogId' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 26
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 26
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'FirstName' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 27
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 27
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'UserImage' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 28
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 28
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'BlogTitle' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 29
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 29
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'BlogImage' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 30
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 30
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'BlogDescription' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 31
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 31
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'IsActive' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 32
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 32
ERROR - 2019-07-22 11:56:06 --> Severity: Warning --> Illegal string offset 'statusBlog' C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 54
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Array to string conversion C:\xampps\htdocs\mentor\admin\application\controllers\Blog.php 54
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 38
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 41
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: UserImage C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 46
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: BlogTitle C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 59
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: BlogDescription C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 66
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: IsActive C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 82
ERROR - 2019-07-22 11:56:06 --> Severity: Notice --> Undefined variable: BlogId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 126
ERROR - 2019-07-22 11:56:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:57:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:57:08 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-07-22 11:57:38 --> Severity: Notice --> Undefined variable: ProgramId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 84
ERROR - 2019-07-22 11:57:38 --> Severity: Notice --> Undefined variable: streamData C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 88
ERROR - 2019-07-22 11:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 88
ERROR - 2019-07-22 11:57:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:57:38 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 11:57:38 --> Severity: Notice --> Undefined variable: ProgramId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 84
ERROR - 2019-07-22 11:57:38 --> Severity: Notice --> Undefined variable: streamData C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 88
ERROR - 2019-07-22 11:57:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 88
ERROR - 2019-07-22 11:57:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 11:57:39 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:00:40 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:00:40 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:00:40 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:00:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:00:41 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:09:28 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:09:28 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:09:28 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:09:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:09:29 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:12:35 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:12:35 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:12:35 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:12:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:12:35 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:13:58 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:13:58 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:13:58 --> Severity: Notice --> Undefined variable: BlogStatusId C:\xampps\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 90
ERROR - 2019-07-22 12:13:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:13:58 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:15:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:15:09 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:15:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:15:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:15:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:15:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:17:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:06 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:18:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:16 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:18:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:18:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:18:27 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:21:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:21:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:21:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:21:47 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:21:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:21:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:21:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:21:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:21:53 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:23:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:19 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:23:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:25 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:23:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:34 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:23:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:23:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:23:43 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:25:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:49:07 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:49:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:49:36 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:49:36 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:49:36 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-07-22 12:49:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:49:44 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-07-22 12:54:12 --> Query error: Unknown column 't2.BlogId' in 'on clause' - Invalid query: SELECT *
FROM `tblblogs` as `t1`
LEFT JOIN `tblblogstatus` as `t2` ON `t1`.`BlogId` = `t2`.`BlogId`
ERROR - 2019-07-22 12:54:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-22 12:54:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:54:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-22 12:54:57 --> 404 Page Not Found: Blog/app-assets
