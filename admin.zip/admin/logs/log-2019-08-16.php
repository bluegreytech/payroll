<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-16 06:42:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 06:43:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 06:43:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 06:43:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 06:43:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 06:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 06:43:44 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 203
ERROR - 2019-08-16 07:25:05 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 225
ERROR - 2019-08-16 07:25:05 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 255
ERROR - 2019-08-16 07:27:21 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:27:21 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:29:34 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:29:34 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:30:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 07:30:20 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:30:20 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:30:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 07:30:31 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:30:31 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:31:39 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:31:39 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:31:44 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:31:45 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:31:46 --> 404 Page Not Found: Adminmaster/admin_master_profile
ERROR - 2019-08-16 07:33:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 07:33:15 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:33:15 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:33:51 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:33:51 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:35:41 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:35:41 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:36:24 --> Severity: error --> Exception: Too few arguments to function Adminmaster::editadminmaster(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 33
ERROR - 2019-08-16 07:36:42 --> Severity: error --> Exception: Too few arguments to function Adminmaster::editadminmaster(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 33
ERROR - 2019-08-16 07:36:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:36:58 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:41:15 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:41:15 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:42:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:42:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:45:30 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:45:30 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:46:09 --> Severity: error --> Exception: syntax error, unexpected '$result' (T_VARIABLE) C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 20
ERROR - 2019-08-16 07:46:24 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:46:24 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:46:26 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:46:26 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:48:48 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 13
ERROR - 2019-08-16 07:48:56 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:48:56 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:49:47 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 13
ERROR - 2019-08-16 07:50:17 --> Severity: error --> Exception: Too few arguments to function Adminmaster::adminlist(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 10
ERROR - 2019-08-16 07:57:08 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:57:08 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:57:38 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:57:38 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:57:40 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:57:40 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 07:59:15 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 07:59:15 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 08:01:55 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 08:01:55 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 08:05:12 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 08:05:12 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 08:07:51 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 08:07:51 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 08:07:58 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:07:58 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:07:58 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:08:33 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 210
ERROR - 2019-08-16 08:08:33 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 217
ERROR - 2019-08-16 08:08:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:08:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:08:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:25:00 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:25:03 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:26:00 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:26:08 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:29:04 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:29:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:30:07 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:30:08 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:30:15 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:30:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:30:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:30:18 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:32:47 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:32:47 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:32:48 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:32:48 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:32:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:35:48 --> 404 Page Not Found: Adminmaster/edit
ERROR - 2019-08-16 08:35:51 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:35:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:35:56 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:35:56 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:35:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:35:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:35:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:36:24 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:36:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:36:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:36:25 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:36:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:36:50 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:36:50 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:36:50 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:36:50 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:36:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:37:03 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:37:03 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:37:03 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:37:03 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:37:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:37:12 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:37:12 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:37:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:37:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:37:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:37:21 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 35
ERROR - 2019-08-16 08:38:13 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:38:13 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:38:13 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:38:13 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:38:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:38:44 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 206
ERROR - 2019-08-16 08:38:45 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:38:45 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:38:45 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:38:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:39:23 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:39:23 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:39:23 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:39:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:40:37 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:40:37 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:40:37 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:40:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:42:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:42:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:42:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:42:28 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:42:52 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:42:52 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:42:52 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:42:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:43:11 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:43:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:43:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:43:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:43:39 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:43:39 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:43:40 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:43:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:45:28 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:45:29 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:45:29 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:45:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:48:08 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:48:08 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:48:08 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:52:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:52:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:52:47 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:53:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:53:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:53:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:54:17 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 08:54:17 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:54:17 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 08:55:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 08:57:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 09:20:52 --> Severity: Notice --> Array to string conversion C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 21
ERROR - 2019-08-16 09:27:13 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 26
ERROR - 2019-08-16 09:27:42 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 26
ERROR - 2019-08-16 09:36:58 --> 404 Page Not Found: Adminmaster/upload
ERROR - 2019-08-16 09:36:58 --> 404 Page Not Found: Adminmaster/upload
ERROR - 2019-08-16 09:37:00 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 09:37:00 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 09:37:00 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 09:37:59 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 09:37:59 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 09:37:59 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 10:11:38 --> 404 Page Not Found: Adminmaster/deleteadmin2
ERROR - 2019-08-16 10:12:01 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 10:58:27 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 10:58:27 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 10:58:27 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 11:00:20 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 290
ERROR - 2019-08-16 11:00:20 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 11:00:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:00:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:02:43 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 11:02:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:02:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:08:56 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:08:56 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:08:56 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 11:11:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:11:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 11:11:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 11:11:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 11:12:54 --> Severity: error --> Exception: Too few arguments to function Adminmaster::deleteadmin(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 59
ERROR - 2019-08-16 11:18:13 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:18:40 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:19:14 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:19:40 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:19:58 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:22:30 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:23:50 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 61
ERROR - 2019-08-16 11:57:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 11:58:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 11:58:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 11:58:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 11:58:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 11:58:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-16 11:58:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 11:58:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 12:04:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:04:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:04:57 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 12:06:12 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 12:06:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:06:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:24:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 12:24:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 12:26:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:26:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:26:30 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 12:29:52 --> 404 Page Not Found: Default/css
ERROR - 2019-08-16 12:29:52 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:29:52 --> 404 Page Not Found: Default/js
ERROR - 2019-08-16 12:54:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:22:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:33:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 263
ERROR - 2019-08-16 13:34:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 263
ERROR - 2019-08-16 13:37:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 182
ERROR - 2019-08-16 13:37:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 182
ERROR - 2019-08-16 13:37:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:37:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:42:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:42:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:42:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 13:43:06 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:45:47 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:48:04 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:48:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:48:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 13:48:26 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:53:08 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:53:08 --> Severity: Notice --> Array to string conversion C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 167
ERROR - 2019-08-16 13:53:48 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:54:44 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:57:02 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:57:16 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:58:18 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:58:34 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:58:57 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:59:03 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:59:13 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 13:59:40 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 14:00:52 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 14:05:01 --> The upload path does not appear to be valid.
ERROR - 2019-08-16 14:06:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-16 14:06:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 14:24:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 14:24:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-16 14:24:34 --> 404 Page Not Found: Default/cdn-cgi
