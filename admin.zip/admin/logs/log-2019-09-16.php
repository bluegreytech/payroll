<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-16 08:00:22 --> 404 Page Not Found: Assets/img
