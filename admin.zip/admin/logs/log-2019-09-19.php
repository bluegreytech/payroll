<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-19 06:09:15 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 06:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 06:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 06:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 06:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 06:09:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 06:35:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 06:45:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 06:48:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 06:50:13 --> Query error: Not unique table/alias: 't2' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `isdelete` = '0'
ORDER BY `Companyinvoiceid` DESC
ERROR - 2019-09-19 06:51:17 --> Query error: Unknown table 't4' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t3` ON `t1`.`companyid` = `t3`.`companyid`
WHERE `t1`.`isdelete` = '0'
ORDER BY `t1`.`Companyinvoiceid` DESC
ERROR - 2019-09-19 06:59:54 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 86
ERROR - 2019-09-19 07:03:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: companyname C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 93
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 94
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: companyname C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 93
ERROR - 2019-09-19 07:04:48 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 94
ERROR - 2019-09-19 07:08:02 --> Query error: Unknown column 't2.hr_id' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t3` ON `t2`.`hr_id` = `t3`.`hr_id`
WHERE `t1`.`isdelete` = '0'
ORDER BY `t1`.`Companyinvoiceid` DESC
ERROR - 2019-09-19 07:11:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:14:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:18:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 07:18:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 07:18:45 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-19 07:18:45 --> 404 Page Not Found: Default/css
ERROR - 2019-09-19 07:22:39 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 85
ERROR - 2019-09-19 07:23:13 --> Severity: Notice --> Undefined variable: ccompInvoiceomp C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:23:13 --> Severity: Notice --> Undefined variable: ccompInvoiceomp C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-reports.php 92
ERROR - 2019-09-19 07:30:08 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 24
ERROR - 2019-09-19 07:30:09 --> Query error: Not unique table/alias: 't2' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`companyid` IS NULL
ERROR - 2019-09-19 07:33:59 --> 404 Page Not Found: Invoice/invoice
ERROR - 2019-09-19 07:41:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:41:26 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 33
ERROR - 2019-09-19 07:42:20 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 33
ERROR - 2019-09-19 07:42:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:43:19 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 33
ERROR - 2019-09-19 07:43:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:43:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 07:50:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-19 09:37:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 09:37:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 09:52:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:03:37 --> Severity: Notice --> Undefined variable: taxamountper C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 137
ERROR - 2019-09-19 10:07:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:08:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:10:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:26:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:30:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:54:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 10:54:50 --> Query error: Column 'discount' cannot be null - Invalid query: INSERT INTO `tblcompanyinvoice` (`companyid`, `hr_id`, `invoicedate`, `duedate`, `totalamount`, `taxamount`, `discount`, `netamount`, `Isactive`) VALUES ('1', '2', '02/09/2019', '03/09/2019', '100', '100', NULL, '400', 'Aactive')
ERROR - 2019-09-19 11:10:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:12:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:13:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:18:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:19:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:26:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:26:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:26:47 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:26:47 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:26:47 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:26:47 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:27:49 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:27:49 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:27:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:27:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:27:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:27:50 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:27:50 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:27:50 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:27:50 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:27:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:28:04 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:28:04 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:28:04 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:28:04 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:31:00 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:00 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:00 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:00 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:31:16 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:16 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:16 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:16 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:31:39 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:39 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:39 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:39 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:59 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:59 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 216
ERROR - 2019-09-19 11:31:59 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:59 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 222
ERROR - 2019-09-19 11:31:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:32:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:32:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:32:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:32:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:32:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 11:32:49 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:32:49 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:32:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:32:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:33:07 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:33:07 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:33:07 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:33:07 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:33:15 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:33:15 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 11:33:15 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:33:15 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 11:33:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:34:48 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:34:49 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:34:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:34:49 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:34:57 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:34:57 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:34:57 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:34:57 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:35:20 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:20 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:20 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:20 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:45 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:45 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:35:45 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:35:45 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:38:17 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:38:17 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:38:17 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:38:17 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:38:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 12:38:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 12:38:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-19 12:38:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-19 12:41:06 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:41:06 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:41:06 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:41:06 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:41:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:41:34 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:41:34 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:41:34 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:41:34 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:41:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:43:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:43:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:43:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:43:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:43:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:45:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:45:24 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:45:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:45:24 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:45:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:45:36 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:45:36 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:45:36 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:45:36 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:45:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:47:30 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:47:30 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:47:30 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:47:30 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:47:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:48:40 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:48:40 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:48:40 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:48:40 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:48:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:49:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:49:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:49:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:49:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:49:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:49:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 251
ERROR - 2019-09-19 12:49:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:49:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 257
ERROR - 2019-09-19 12:50:05 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:50:05 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:50:06 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:50:06 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:50:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:51:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:51:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:52:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:53:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:53:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:53:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:54:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:54:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:54:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:57:16 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:57:17 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:57:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:57:45 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:57:45 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:57:45 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:57:45 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:57:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:58:27 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:27 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:27 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:27 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:31 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:31 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 12:58:46 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:46 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:58:46 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:46 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:58:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:59:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:59:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:59:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:59:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 12:59:08 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:59:08 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 215
ERROR - 2019-09-19 12:59:08 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 12:59:08 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 221
ERROR - 2019-09-19 13:01:03 --> 404 Page Not Found: Adminmaster/%3C
ERROR - 2019-09-19 13:01:08 --> 404 Page Not Found: Adminmaster/%3C
ERROR - 2019-09-19 13:01:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 13:01:25 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 214
ERROR - 2019-09-19 13:01:25 --> Severity: Notice --> Undefined variable: invoicedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 214
ERROR - 2019-09-19 13:01:25 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 219
ERROR - 2019-09-19 13:01:25 --> Severity: Notice --> Undefined variable: duedate C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 219
ERROR - 2019-09-19 13:02:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 13:03:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 13:03:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 16:58:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 17:07:34 --> Query error: Unknown column 't2.hr_id' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t3` ON `t2`.`hr_id` = `t3`.`hr_id`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-19 17:12:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 17:21:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 17:21:09 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:21:17 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:21:19 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:21:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 17:28:01 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:28:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:28:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:28:05 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-19 17:28:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-19 17:28:10 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:28:13 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:32:11 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:32:13 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:32:15 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-19 17:32:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-19 17:47:40 --> Severity: Notice --> Undefined index: statename C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 121
ERROR - 2019-09-19 17:47:53 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:47:53 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:47:53 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-19 17:47:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-19 17:48:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-19 17:48:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:48:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-19 17:48:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-19 17:54:46 --> Severity: Notice --> Undefined variable: Companyinvoiceid C:\xampp\htdocs\payroll\admin\application\views\Invoice\invoice-view.php 74
ERROR - 2019-09-19 18:03:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Notification_model C:\xampp\htdocs\payroll\admin\system\core\Loader.php 348
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-19 18:04:49 --> 404 Page Not Found: Assets/img
