ERROR - 2019-09-09 12:26:26 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employeadd.php 99
ERROR - 2019-09-09 12:26:29 --> Query error: Unknown column 't1.Is_deleted' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companytype`
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
WHERE `t1`.`Is_deleted` = '0'
AND `t1`.`isactive` = 'Active'
AND `t1`.`isdelete` = '0'
ORDER BY `companyid` DESC
ERROR - 2019-09-09 12:30:50 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 232
ERROR - 2019-09-09 12:30:50 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 234
ERROR - 2019-09-09 12:34:05 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 232
ERROR - 2019-09-09 12:34:05 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 234
ERROR - 2019-09-09 12:34:20 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 232
ERROR - 2019-09-09 12:34:20 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 234
ERROR - 2019-09-09 12:35:09 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 232
ERROR - 2019-09-09 12:35:09 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 234
ERROR - 2019-09-09 12:37:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 12:41:36 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 232
ERROR - 2019-09-09 12:41:36 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 234
ERROR - 2019-09-09 12:42:45 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 536
ERROR - 2019-09-09 12:43:11 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 536
ERROR - 2019-09-09 12:43:46 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 536
ERROR - 2019-09-09 12:52:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 12:53:01 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 516
