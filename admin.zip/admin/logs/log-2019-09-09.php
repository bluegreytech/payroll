<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-09 06:35:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'payrolldb' C:\xampp\htdocs\payroll\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-09-09 06:35:02 --> Unable to connect to the database
ERROR - 2019-09-09 06:35:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'payrolldb' C:\xampp\htdocs\payroll\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-09-09 06:35:05 --> Unable to connect to the database
ERROR - 2019-09-09 06:38:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:39:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 06:39:21 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 57
ERROR - 2019-09-09 06:39:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 06:39:49 --> Query error: Unknown column 'IsDelete' in 'where clause' - Invalid query: SELECT *
FROM `tblhr`
WHERE `IsDelete` != 1
ERROR - 2019-09-09 06:42:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:42:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:42:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:42:54 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:42:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 06:42:59 --> Query error: Unknown column 't1.IsDelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsDelete` != 1
ERROR - 2019-09-09 06:44:11 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:44:59 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:45:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 06:45:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:45:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 06:46:10 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:48:20 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:49:09 --> Query error: Unknown column 't1.IsDelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsDelete` != 1
ERROR - 2019-09-09 06:49:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 06:50:58 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:52:21 --> Query error: Unknown column 't1.IsDelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsDelete` != 1
ERROR - 2019-09-09 06:54:32 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_delete` != 1
ERROR - 2019-09-09 06:57:15 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 06:57:35 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:00:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:00:27 --> Query error: Column 'IsActive' in where clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `IsActive` = 1
AND `Is_delete` = 0
ERROR - 2019-09-09 07:00:46 --> Query error: Column 'IsActive' in where clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `IsActive` = 1
AND `Is_delete` = 0
ERROR - 2019-09-09 07:01:56 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsActive` = 1
AND `t1`.`Is_delete` = 0
ERROR - 2019-09-09 07:03:00 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsActive` = 'Active'
AND `t1`.`Is_delete` = 0
ERROR - 2019-09-09 07:03:01 --> Query error: Unknown column 't1.Is_delete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`IsActive` = 'Active'
AND `t1`.`Is_delete` = 0
ERROR - 2019-09-09 07:05:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:10 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:54 --> Query error: Unknown column 'IsDelete' in 'field list' - Invalid query: UPDATE `tblhr` SET `IsDelete` = 1, `IsActive` = 'Inactive'
WHERE `hr_id` = '1'
ERROR - 2019-09-09 07:06:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:06:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:07:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:07:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:07:40 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:09:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:09:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:09:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:09:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:09:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:09:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:09:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:10:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:10:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:10:38 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:10:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:10:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:12:23 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:13:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:16:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:17:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:18:13 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:18:28 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:18:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:18:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:19:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:19:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:03 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:24 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:49 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:20:58 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 07:34:26 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:26 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:26 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:26 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:34 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:34 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:34 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:34:34 --> Severity: Notice --> Undefined variable: comyyyy C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 215
ERROR - 2019-09-09 07:38:39 --> 404 Page Not Found: Compliance/index
ERROR - 2019-09-09 07:43:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:45:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 07:51:20 --> 404 Page Not Found: Compliance/index
ERROR - 2019-09-09 07:51:46 --> 404 Page Not Found: Compliance/index
ERROR - 2019-09-09 08:06:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:06:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:07:36 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:08:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:08:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:08:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:00 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:09 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:09:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:10:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:10:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:10:55 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:11:21 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:13:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:21:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:22:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:22:05 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 57
ERROR - 2019-09-09 08:22:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:22:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:22:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:22:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:22:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:22:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 08:22:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:22:46 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 50
ERROR - 2019-09-09 08:23:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:23:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:23:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:23:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-09 08:23:58 --> Severity: Notice --> Undefined index: AdminId C:\xampp\htdocs\payroll\admin\application\controllers\Adminmaster.php 205
ERROR - 2019-09-09 08:23:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-09 08:24:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-09 08:27:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-09 08:27:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-09 08:30:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:30:32 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 57
ERROR - 2019-09-09 08:30:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:30:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:30:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:33:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:33:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:33:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:34:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:34:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:35:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:36:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 08:36:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:36:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:36:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:36:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 08:36:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:36:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:38:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:38:35 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:38:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:39:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:39:22 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:40:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:40:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:40:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:41:07 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:41:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:41:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:41:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 08:56:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 09:01:46 --> Query error: Column 'isactive' in where clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.`companytype`
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
WHERE `isactive` = 'Active'
AND `isdelete` = '0'
ORDER BY `companyid` DESC
ERROR - 2019-09-09 09:04:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:04:33 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:09:03 --> Query error: Unknown column 't1.isactive' in 'where clause' - Invalid query: SELECT *
FROM `tblcompany`
WHERE `t1`.`isactive` = 'Active'
AND `t1`.`isdelete` = '0'
ERROR - 2019-09-09 09:10:04 --> Query error: Unknown column 't1.UserId' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*
FROM `tblhr` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `t1`.`UserId` = 1
ERROR - 2019-09-09 09:12:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:12:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:13:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:14:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-09 09:14:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 24
ERROR - 2019-09-09 09:14:28 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 57
ERROR - 2019-09-09 09:17:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:17:47 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:18:05 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:18:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:18:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:18:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:19:06 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:19:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:19:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:20:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:21:31 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:21:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:21:52 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:22:02 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 09:23:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 10:09:20 --> Severity: Notice --> Undefined property: Company::$Login_model C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:09:20 --> Severity: error --> Exception: Call to a member function getcompliance() on null C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:20 --> Severity: Notice --> Undefined property: Company::$Login_model C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:20 --> Severity: error --> Exception: Call to a member function getcompliance() on null C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:22 --> Severity: Notice --> Undefined property: Company::$Login_model C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:22 --> Severity: error --> Exception: Call to a member function getcompliance() on null C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:42 --> Severity: Notice --> Undefined property: Company::$Login_model C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:12:42 --> Severity: error --> Exception: Call to a member function getcompliance() on null C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 192
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:18:22 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:19:00 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:20:13 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 212
ERROR - 2019-09-09 10:24:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:25:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:26:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:27:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:27:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:28:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:28:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> Severity: Notice --> Undefined variable: seldata C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 213
ERROR - 2019-09-09 10:28:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:28:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:29:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:29:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:30:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:30:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:30:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:30:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:31:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:32:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:46 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:34:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 206
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 206
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 205
ERROR - 2019-09-09 10:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 206
ERROR - 2019-09-09 10:35:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:35:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:36:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:36:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:36:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:37:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:37:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:38:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:38:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:38:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:38:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:38:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:38:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:38:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:39:24 --> Severity: Notice --> Undefined index: companycompliances C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:39:24 --> Severity: Notice --> Undefined index: companycompliances C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:39:24 --> Severity: Notice --> Undefined index: companycompliances C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:39:24 --> Severity: Notice --> Undefined index: companycompliances C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 207
ERROR - 2019-09-09 10:39:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:39:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:39:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:40:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:40:22 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:40:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:40:32 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:40:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:40:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:40:50 --> Severity: Notice --> Undefined index: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:40:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:41:26 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:41:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:42:20 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:42:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:43:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:43:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:44:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:44:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:44:23 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:44:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:44:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:44:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:44:56 --> Severity: Notice --> Trying to get property 'compliance_id' of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:44:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:45:14 --> Severity: Notice --> Undefined index: compliance_id C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 210
ERROR - 2019-09-09 10:45:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:45:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:47:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:47:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:47:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:48:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:48:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 10:52:42 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 10:52:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 10:56:37 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:08:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:21:48 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:22:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:22:20 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:22:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:38:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:38:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-09 11:38:59 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:39:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:39:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:42:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:42:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-09 11:42:57 --> 404 Page Not Found: Uploads/default
