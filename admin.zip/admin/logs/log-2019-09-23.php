<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-23 05:57:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-23 05:57:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-23 05:57:28 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-23 05:57:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-23 05:57:43 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-23 05:57:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-23 05:57:55 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-23 05:58:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-23 05:58:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-23 05:58:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-23 05:58:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-23 05:58:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-23 06:10:23 --> Severity: Notice --> Undefined property: Employee::$Company_model C:\xampp\htdocs\payroll\admin\application\controllers\Employee.php 45
ERROR - 2019-09-23 06:10:23 --> Severity: error --> Exception: Call to a member function get_employeeprofile() on null C:\xampp\htdocs\payroll\admin\application\controllers\Employee.php 45
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined index: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\controllers\Employee.php 54
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: companyname C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 87
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 93
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:22:51 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined index: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\controllers\Employee.php 54
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: companyname C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 87
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 93
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:23:24 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: companyname C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 87
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 93
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:23:29 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:23:30 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 93
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:24:38 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 93
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:24:54 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:25:27 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 100
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:26:02 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:26:41 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: gstnumber C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 106
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:28:39 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 113
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 121
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 130
ERROR - 2019-09-23 06:33:57 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 145
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 179
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 184
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 231
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:33:58 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 119
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 119
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 127
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 136
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 151
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 157
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 185
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 190
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 237
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 237
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:34:21 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 126
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 126
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 134
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 143
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 158
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 192
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 197
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:34:58 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 251
ERROR - 2019-09-23 06:34:59 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 251
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:35:40 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:40:48 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 132
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:41:12 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:41:50 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:42:08 --> Severity: Notice --> Undefined variable: digitalsignaturedate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 257
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:42:39 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:42:42 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:43:52 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: companyaddress C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 140
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:43:54 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: stateData C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 149
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 164
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 170
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 198
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 203
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:44:27 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 250
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: companycity C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 147
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 153
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 181
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 186
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:44:53 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: pincode C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 153
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 181
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 186
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:45:41 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 181
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: isactive C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 186
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:46:05 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:46:37 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:46:37 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:46:37 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 194
ERROR - 2019-09-23 06:46:37 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 194
ERROR - 2019-09-23 06:47:24 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:47:24 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:47:24 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 202
ERROR - 2019-09-23 06:47:24 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 202
ERROR - 2019-09-23 06:48:12 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:48:12 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:48:12 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 207
ERROR - 2019-09-23 06:48:12 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 207
ERROR - 2019-09-23 06:48:46 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:48:46 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:48:46 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 214
ERROR - 2019-09-23 06:48:46 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 214
ERROR - 2019-09-23 06:49:18 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:49:18 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:49:18 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 220
ERROR - 2019-09-23 06:49:18 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 220
ERROR - 2019-09-23 06:53:07 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:53:07 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:53:07 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 241
ERROR - 2019-09-23 06:53:07 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 241
ERROR - 2019-09-23 06:53:22 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:53:22 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:53:22 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 234
ERROR - 2019-09-23 06:53:22 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 234
ERROR - 2019-09-23 06:54:32 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:54:32 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:54:32 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:54:32 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 233
ERROR - 2019-09-23 06:55:14 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:55:14 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:55:14 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:55:14 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 238
ERROR - 2019-09-23 06:56:22 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:56:22 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:56:22 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:56:22 --> Severity: Notice --> Undefined variable: Enddate C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 244
ERROR - 2019-09-23 06:58:02 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:58:02 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 06:59:08 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 06:59:08 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 07:01:03 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 49
ERROR - 2019-09-23 07:01:03 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 07:03:48 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 07:04:31 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Employee\profile.php 61
ERROR - 2019-09-23 08:57:23 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 600
ERROR - 2019-09-23 09:25:20 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 09:25:21 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 09:25:21 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 09:25:21 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 09:25:34 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 09:25:34 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 09:25:34 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 09:25:34 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:52:51 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:52:51 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:52:51 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:52:51 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:53:55 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:53:55 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:53:55 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:53:55 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:06 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:06 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:06 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:06 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:26 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:26 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:26 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:26 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:36 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:36 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 585
ERROR - 2019-09-23 10:58:36 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 10:58:36 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 592
ERROR - 2019-09-23 11:17:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 623
ERROR - 2019-09-23 11:17:36 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:17:36 --> Severity: Notice --> Undefined variable: data3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 639
ERROR - 2019-09-23 11:20:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 623
ERROR - 2019-09-23 11:20:42 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:20:42 --> Query error: Column 'companyid' cannot be null - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (NULL, '2', 't', '2', '1')
ERROR - 2019-09-23 11:22:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 623
ERROR - 2019-09-23 11:22:49 --> Query error: Column 'companyid' cannot be null - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (NULL, '2', 't', '0', '0')
ERROR - 2019-09-23 11:26:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 623
ERROR - 2019-09-23 11:33:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 623
ERROR - 2019-09-23 11:45:51 --> Query error: Column 'companyid' cannot be null - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (NULL, '2', ' first', '12:59', '12:59')
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:07 --> Severity: Notice --> Uninitialized string offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:08 --> Severity: Notice --> Uninitialized string offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:09 --> Severity: Notice --> Uninitialized string offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:10 --> Severity: Notice --> Uninitialized string offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:11 --> Severity: Notice --> Uninitialized string offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:12 --> Severity: Notice --> Uninitialized string offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:13 --> Severity: Notice --> Uninitialized string offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 132 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 132 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 133 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 133 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 134 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:14 --> Severity: Notice --> Uninitialized string offset: 134 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 135 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 135 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 136 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 136 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 137 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 137 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 138 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 138 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 139 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 139 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 140 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 140 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 141 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 141 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 142 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 142 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 143 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 143 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 144 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 144 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 145 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 145 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 146 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 146 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 147 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:15 --> Severity: Notice --> Uninitialized string offset: 147 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 148 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 148 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 149 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 149 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 150 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 150 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 151 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 151 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 152 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 152 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 153 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 153 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 154 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 154 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 155 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 155 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 156 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 156 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 157 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 157 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 158 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 158 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 159 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 159 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 160 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 160 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 161 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 161 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 162 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 162 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 163 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 163 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 164 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 164 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 165 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 165 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 166 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:16 --> Severity: Notice --> Uninitialized string offset: 166 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 167 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 167 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 168 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 168 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 169 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 169 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 170 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 170 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 171 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 171 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 172 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 172 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 173 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 173 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 174 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 174 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 175 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 175 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 176 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 176 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 177 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 177 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 178 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 178 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 179 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 179 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 180 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 180 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 181 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 181 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 182 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 182 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 183 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 183 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 184 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:17 --> Severity: Notice --> Uninitialized string offset: 184 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 185 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 185 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 186 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 186 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 187 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 187 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 188 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 188 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 189 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 189 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 190 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 190 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 191 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 191 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 192 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 192 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 193 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 193 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 194 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 194 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 195 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 195 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 196 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 196 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 197 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 197 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 198 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 198 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 199 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 199 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:18 --> Severity: Notice --> Uninitialized string offset: 200 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 200 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 201 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 201 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 202 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 202 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 203 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 203 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 204 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 204 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 205 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 205 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 206 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 206 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 207 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 207 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 208 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 208 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 209 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 209 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 210 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 210 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 211 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 211 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 212 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 212 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 213 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 213 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 214 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 214 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 215 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 215 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 216 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 632
ERROR - 2019-09-23 11:56:19 --> Severity: Notice --> Uninitialized string offset: 216 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 633
ERROR - 2019-09-23 12:18:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1471
ERROR - 2019-09-23 12:18:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1471
ERROR - 2019-09-23 12:18:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1471
ERROR - 2019-09-23 12:18:43 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (24, '24', Array, Array, Array)
ERROR - 2019-09-23 12:22:04 --> Query error: Column 'companyid' cannot be null - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (NULL, '2', ' first', '12:59', '12:58')
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:14 --> Severity: Notice --> Uninitialized string offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:15 --> Severity: Notice --> Uninitialized string offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:16 --> Severity: Notice --> Uninitialized string offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:17 --> Severity: Notice --> Uninitialized string offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:18 --> Severity: Notice --> Uninitialized string offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:19 --> Severity: Notice --> Uninitialized string offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:20 --> Severity: Notice --> Uninitialized string offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:23:21 --> Severity: Notice --> Uninitialized string offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:03 --> Severity: Notice --> Undefined offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 132 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 133 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 134 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 135 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 136 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 137 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 138 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 139 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 140 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 141 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 142 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 143 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 144 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 145 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 146 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 147 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 148 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 149 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 150 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 151 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 152 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 153 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 154 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 155 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 156 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 157 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 158 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 159 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 160 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:04 --> Severity: Notice --> Undefined offset: 161 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 162 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 163 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 164 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 165 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 166 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 167 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 168 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 169 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 170 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 171 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 172 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 173 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 174 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 175 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 176 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 177 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 178 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 179 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 180 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 181 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 182 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 183 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 184 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 185 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 186 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 187 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 188 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 189 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 190 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 191 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 192 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 193 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 194 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 195 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 196 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 197 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 198 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 199 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 200 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 201 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 202 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 203 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 204 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 205 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 206 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 207 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 208 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 209 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 210 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 211 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 212 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 213 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 214 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 215 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 216 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 217 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 218 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 219 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 220 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 221 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 222 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 223 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 224 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 225 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 226 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 227 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 228 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 229 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 230 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 231 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 232 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 233 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 234 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 235 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 236 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 237 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 238 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 239 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 240 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 241 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 242 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 243 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 244 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 245 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 246 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 247 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 248 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 249 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 250 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 251 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 252 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 253 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 254 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 255 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 256 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 257 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 258 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 259 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:05 --> Severity: Notice --> Undefined offset: 260 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 261 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 262 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 263 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 264 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 265 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 266 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 267 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 268 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 269 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 270 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 271 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:32:06 --> Severity: Notice --> Undefined offset: 272 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 636
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:04 --> Severity: Notice --> Undefined offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 132 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 133 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 134 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 135 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 136 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 137 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 138 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 139 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 140 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 141 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 142 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 143 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 144 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 145 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 146 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 147 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 148 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 149 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 150 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 151 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 152 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 153 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 154 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 155 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 156 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 157 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 158 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 159 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 160 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 161 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 162 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 163 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 164 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 165 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 166 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 167 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 168 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 169 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 170 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 171 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 172 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 173 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 174 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 175 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 176 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 177 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 178 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 179 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 180 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 181 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 182 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 183 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 184 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 185 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 186 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 187 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:05 --> Severity: Notice --> Undefined offset: 188 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 189 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 190 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 191 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 192 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 193 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 194 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 195 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 196 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 197 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 198 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 199 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 200 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 201 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 202 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 203 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 204 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 205 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 206 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 207 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 208 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 209 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 210 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 211 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 212 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 213 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 214 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 215 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 216 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 217 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 218 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 219 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 220 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 221 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 222 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 223 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 224 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 225 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 226 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 227 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 228 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 229 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 230 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 231 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 232 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 233 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 234 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 235 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 236 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 237 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 238 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 239 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 240 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 241 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 242 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 243 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 244 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 245 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 246 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 247 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 248 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 249 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 250 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 251 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 252 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 253 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 254 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 255 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 256 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 257 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 258 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 259 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 260 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 261 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 262 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 263 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 264 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 265 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 266 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 267 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 268 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 269 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 270 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 271 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 272 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 273 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 274 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 275 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 276 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 277 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 278 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 279 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 280 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 281 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 282 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:06 --> Severity: Notice --> Undefined offset: 283 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 284 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 285 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 286 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 287 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 288 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 289 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 290 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 291 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 292 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 293 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 294 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 295 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 296 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 297 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 298 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 299 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 300 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 301 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 302 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 303 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 304 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 305 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 306 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 307 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 308 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 309 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 310 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 311 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 312 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 313 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 314 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 315 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 316 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 317 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 318 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 319 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 320 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 321 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 322 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 323 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 324 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 325 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 326 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 327 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 328 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 329 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 330 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 331 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 332 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 333 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 334 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 335 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 336 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 337 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 338 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 339 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 340 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 341 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 342 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 343 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 344 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 345 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 346 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 347 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 348 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 349 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 350 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 351 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 352 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 353 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 354 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 355 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 356 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 357 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 358 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 359 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 360 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 361 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 362 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 363 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 364 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 365 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 366 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 367 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 368 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 369 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 370 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 371 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 372 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 373 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 374 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 375 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:07 --> Severity: Notice --> Undefined offset: 376 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 377 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 378 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 379 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 380 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 381 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 382 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 383 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 384 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 385 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 386 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 387 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 388 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 389 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 390 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 391 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 392 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 393 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 394 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 395 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 396 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 397 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 398 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 399 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 400 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 401 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 402 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 403 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 404 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 405 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 406 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 407 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 408 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 409 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 410 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 411 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 412 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 413 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 414 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 415 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 12:41:08 --> Severity: Notice --> Undefined offset: 416 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 635
ERROR - 2019-09-23 13:22:30 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-23 13:27:26 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-23 13:30:34 --> 404 Page Not Found: Profilehtml/index
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: emp_id C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 45
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: employee_code C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 87
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 93
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:37:38 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:37:39 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:37:39 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:37:39 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:37:39 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:37:39 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: emp_id C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 45
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: employee_code C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 87
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 93
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:38:46 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:39:07 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:39:07 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: companyid C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 77
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: employee_code C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 87
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 93
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:39:08 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: employee_code C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 87
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 93
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:40:18 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:40:19 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: department C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 93
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:42:31 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: desgination C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 100
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 106
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:23 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 112
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:43:51 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 119
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: Father_name C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 125
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 132
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 140
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 147
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 160
ERROR - 2019-09-23 13:44:21 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 167
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 174
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 187
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 199
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 205
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 212
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 219
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 225
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 264
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:44:22 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 271
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 121
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 121
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 129
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 136
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 149
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 156
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 163
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 170
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 176
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 182
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 188
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 194
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 201
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 201
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 208
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 214
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 253
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 253
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 260
ERROR - 2019-09-23 13:45:03 --> Severity: Notice --> Undefined variable: Dateofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 260
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: Placeofbirth C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 129
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: marital_status C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 136
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 149
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 156
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 163
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 170
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 176
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 182
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 188
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 194
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 201
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 201
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 208
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 214
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 253
ERROR - 2019-09-23 13:45:49 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 253
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 143
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 150
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: religion C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 157
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: nationality C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 164
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: qualification_emp C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 170
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: bloodgroup C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 176
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: probation_preriod_day C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 182
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: physically_challenged C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 188
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 195
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 195
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: salaryamt C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 202
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: salary C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 208
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 247
ERROR - 2019-09-23 13:46:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 247
ERROR - 2019-09-23 13:47:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:47:46 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 181
ERROR - 2019-09-23 13:48:13 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 186
ERROR - 2019-09-23 13:48:13 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 186
ERROR - 2019-09-23 13:48:38 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:48:38 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:49:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:49:19 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:50:10 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:50:10 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:52:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:52:08 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:52:23 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-23 13:53:30 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:53:30 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 192
ERROR - 2019-09-23 13:54:07 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:07 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:47 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:47 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:56 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:56 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:54:59 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:55:06 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:55:06 --> Severity: Notice --> Undefined variable: joiningdate C:\xampp\htdocs\payroll\admin\application\views\hr\profile.php 193
ERROR - 2019-09-23 13:57:00 --> Severity: Notice --> Undefined index: discount C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 118
ERROR - 2019-09-23 14:08:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-23 14:08:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-23 14:08:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-23 14:08:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-23 14:18:23 --> Severity: Notice --> Undefined index: discount C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 118
