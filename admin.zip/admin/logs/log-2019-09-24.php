<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-24 05:44:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-24 05:44:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-24 05:44:32 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-24 05:44:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-24 05:44:37 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-24 05:44:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-24 05:44:40 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-24 05:44:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-24 05:44:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-24 05:44:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-24 05:44:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-24 05:44:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-24 06:19:43 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1471
ERROR - 2019-09-24 06:19:43 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tblcompanyshift` (`companyid`, `Shifthours`, `Shiftname`, `Shiftintime`, `Shiftouttime`) VALUES (55, Array, 'first shift', '10:00', '19:00')
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 945
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 121
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 284
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 298
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 352
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 359
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 367
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 532
ERROR - 2019-09-24 06:54:10 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 533
ERROR - 2019-09-24 06:54:16 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 06:54:16 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 06:54:16 --> 404 Page Not Found: Default/css
ERROR - 2019-09-24 06:54:16 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: insert_id C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 953
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 121
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 284
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 298
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 352
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 359
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 367
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 532
ERROR - 2019-09-24 06:55:12 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 533
ERROR - 2019-09-24 06:55:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 06:55:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-24 06:55:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 06:55:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 121
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 284
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 298
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 352
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 359
ERROR - 2019-09-24 06:55:57 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 367
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 121
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 284
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 298
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 352
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 359
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 367
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 381
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 406
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 521
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 528
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 536
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 521
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 528
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 536
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 521
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 528
ERROR - 2019-09-24 07:21:45 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 536
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 119
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 282
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Companyshiftid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 296
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:22:33 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 519
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 526
ERROR - 2019-09-24 07:23:03 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 534
ERROR - 2019-09-24 07:31:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 954
ERROR - 2019-09-24 07:32:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 954
ERROR - 2019-09-24 07:33:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 954
ERROR - 2019-09-24 07:34:53 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 964
ERROR - 2019-09-24 07:34:53 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:34:53 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 966
ERROR - 2019-09-24 07:34:53 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 967
ERROR - 2019-09-24 07:42:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 954
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 304
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 315
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 323
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:42:05 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:42:06 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:42:06 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:42:06 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:42:06 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 570
ERROR - 2019-09-24 07:42:06 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 571
ERROR - 2019-09-24 07:43:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 954
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 304
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 315
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shifthours C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 323
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 570
ERROR - 2019-09-24 07:43:17 --> Severity: Notice --> Undefined variable: complianceid C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 571
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:44:20 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 2 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 3 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 4 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 5 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 6 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 7 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 8 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 9 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 10 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 11 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 12 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 13 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 14 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 15 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 16 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 17 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 18 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 19 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 20 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 21 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 22 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 23 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 24 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 25 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 26 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 27 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 28 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 29 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 30 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 31 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 32 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 33 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 34 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 35 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 36 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 37 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 38 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 39 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 40 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 41 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 42 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 43 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 44 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 45 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 46 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 47 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 48 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 49 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 50 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 51 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 52 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 53 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 54 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 55 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 56 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 57 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 58 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 59 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 60 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 61 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 62 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 63 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 64 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 65 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 66 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 67 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 68 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 69 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 70 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 71 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 72 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 73 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 74 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 75 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 76 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 77 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:37 --> Severity: Notice --> Uninitialized string offset: 78 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 79 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 80 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 81 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 82 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 83 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 84 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 85 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 86 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 87 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 88 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 89 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 90 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 91 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 92 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 93 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 94 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 95 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 96 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 97 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 98 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 99 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 100 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 101 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 102 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 103 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 104 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 105 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 106 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 107 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 108 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 109 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 110 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 111 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 112 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 113 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 114 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 115 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 116 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 117 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 118 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 119 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 120 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 121 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 122 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 123 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 124 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 125 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 126 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 127 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 128 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 129 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 130 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 131 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 132 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 133 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 134 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 135 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 136 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 137 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 138 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 139 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 140 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 141 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 142 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 143 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 144 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 145 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 146 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 147 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 148 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 149 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 150 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 151 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 152 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 153 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 154 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 155 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 156 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 157 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 158 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 159 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 160 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 161 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 162 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 163 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 164 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 165 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 166 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 167 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 168 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 169 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 170 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 171 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 172 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 173 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 174 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 175 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 176 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 177 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 178 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 179 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 180 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 181 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 182 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 183 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 184 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 185 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 186 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 187 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 188 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 189 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 190 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 191 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 192 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 193 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 194 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 195 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 196 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 197 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 198 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 199 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 200 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:38 --> Severity: Notice --> Uninitialized string offset: 201 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 202 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 203 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 204 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 205 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 206 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 207 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 208 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 209 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 210 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 211 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 212 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 213 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 214 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 215 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 216 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 217 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 218 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 219 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 220 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 221 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 222 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 223 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 224 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 225 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 226 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 227 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 228 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 229 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 230 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 231 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 232 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 233 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 234 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 235 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 236 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 237 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 238 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 239 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 240 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 241 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 242 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 243 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 244 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 245 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 246 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 247 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 248 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 249 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 250 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 251 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 252 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 253 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 254 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 255 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 256 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 257 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 258 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 259 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 260 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 261 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 262 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 263 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 264 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 265 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 266 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 267 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 268 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 269 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 270 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 271 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 272 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 273 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 274 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 275 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 276 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 277 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 278 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 279 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 280 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 281 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 282 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 283 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 284 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 285 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 286 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 287 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 288 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 289 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 290 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 291 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 292 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 293 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 294 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 295 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 296 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 297 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 298 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 299 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 300 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 301 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 302 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 303 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 304 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 305 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 306 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 307 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 308 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 309 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 310 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 311 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 312 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 313 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 314 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 315 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 316 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 317 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 318 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:39 --> Severity: Notice --> Uninitialized string offset: 319 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 320 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 321 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 322 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 323 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 324 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 325 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 326 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 327 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 328 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 329 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 330 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 331 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 332 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 333 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 334 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 335 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 336 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 337 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 338 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 339 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 340 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 341 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 342 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 343 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 344 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 345 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 346 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 347 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 348 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 349 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 350 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 351 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 352 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 353 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 354 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 355 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 356 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 357 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 358 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 359 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 360 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 361 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 362 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 363 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 364 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 365 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 366 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 367 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 368 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 369 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 370 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 371 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 372 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 373 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 374 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 375 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 376 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 377 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 378 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 379 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 380 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 381 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 382 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 383 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 384 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 385 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 386 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 387 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 388 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 389 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 390 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 391 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 392 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 393 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 394 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 395 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 396 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 397 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 398 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 399 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 400 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 401 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 402 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 403 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 404 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 405 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 406 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 407 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 408 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 409 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 410 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 411 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 412 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 413 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 414 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 415 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 416 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 417 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 418 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 419 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 420 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:40 --> Severity: Notice --> Uninitialized string offset: 421 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 422 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 423 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 424 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 425 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 426 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 427 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 428 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 429 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 430 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 431 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 432 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 433 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 434 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 435 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 436 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 437 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 438 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 439 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 440 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 441 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 442 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 443 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 444 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 445 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 446 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 447 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 448 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 449 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 450 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 451 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 452 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 453 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 454 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 455 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 456 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 457 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 458 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 459 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 460 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 461 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 462 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 463 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 464 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 465 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 466 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 467 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 468 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 469 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 470 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 471 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 472 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 473 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 474 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 475 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 476 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 477 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 478 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 479 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 480 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:44:41 --> Severity: Notice --> Uninitialized string offset: 481 C:\xampp\htdocs\payroll\admin\application\models\Company_model.php 965
ERROR - 2019-09-24 07:46:35 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1519
ERROR - 2019-09-24 07:46:35 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1519
ERROR - 2019-09-24 07:46:35 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\system\database\DB_driver.php 1519
ERROR - 2019-09-24 07:46:35 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tblcompanyshift` SET `Companyshiftid` = '1', `companyid` = '56', `Shifthours` = '16', `Shiftname` = Array, `Shiftintime` = Array, `Shiftouttime` = Array
WHERE `Companyshiftid` = '1'
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 520
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 527
ERROR - 2019-09-24 07:50:11 --> Severity: Notice --> Undefined property: stdClass::$Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 535
ERROR - 2019-09-24 07:50:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 07:50:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-24 07:50:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-24 07:50:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-24 07:52:41 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:52:41 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:52:41 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:52:41 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:52:41 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:52:56 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:52:56 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:52:56 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:52:56 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:52:56 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:53:14 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 350
ERROR - 2019-09-24 07:53:14 --> Severity: Notice --> Undefined variable: Shiftintime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 357
ERROR - 2019-09-24 07:53:14 --> Severity: Notice --> Undefined variable: Shiftouttime C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 365
ERROR - 2019-09-24 07:53:14 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:53:14 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:53:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:53:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:54:51 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:54:51 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:55:24 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:55:24 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:55:43 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:55:43 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:56:35 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:56:35 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:01 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:01 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:07 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:07 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:20 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:20 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:31 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:31 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:38 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:38 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:57:53 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:57:53 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 07:58:16 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 07:58:16 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:00:22 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:00:22 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:01:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:01:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:02:55 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:02:55 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:03:08 --> Severity: Notice --> Undefined index: discount C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 118
ERROR - 2019-09-24 08:03:34 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:03:34 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:04:37 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:04:37 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:09:30 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:09:30 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:13:09 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:13:09 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:13:38 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:13:38 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:14:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:14:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:15:27 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:15:27 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:19:10 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:19:10 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:19:12 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:19:12 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:19:33 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:19:33 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:19:44 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 379
ERROR - 2019-09-24 08:19:44 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 404
ERROR - 2019-09-24 08:39:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 380
ERROR - 2019-09-24 08:39:39 --> Severity: Notice --> Undefined variable: Shiftname C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 405
