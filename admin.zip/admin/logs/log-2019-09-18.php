<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-18 08:45:33 --> Query error: Unknown column 't1.isdelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblemp` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-18 08:46:25 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 207
ERROR - 2019-09-18 08:46:25 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 207
ERROR - 2019-09-18 08:47:07 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 202
ERROR - 2019-09-18 08:47:07 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 202
ERROR - 2019-09-18 08:48:02 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 196
ERROR - 2019-09-18 08:48:02 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 196
ERROR - 2019-09-18 08:50:23 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 193
ERROR - 2019-09-18 08:50:23 --> Severity: Notice --> Undefined property: stdClass::$employeeid C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 193
ERROR - 2019-09-18 09:00:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:00:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 09:01:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:01:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:01:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 09:01:50 --> Query error: Unknown column 't1.isdelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-18 09:01:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:01:53 --> Query error: Unknown column 't1.isdelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-18 09:01:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:02:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:04:34 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:05:36 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 104
ERROR - 2019-09-18 09:05:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:06:20 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 104
ERROR - 2019-09-18 09:06:21 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:08:56 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 104
ERROR - 2019-09-18 09:08:56 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:09:11 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 104
ERROR - 2019-09-18 09:09:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:21 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:34 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 09:11:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:11:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:13:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:13:42 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:13:50 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:13:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:13:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 09:14:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:14:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:16:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:16:23 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 09:16:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 09:16:30 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:17:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:17:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:18:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:18:32 --> Query error: Unknown column 'empfirstname' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblemp` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_deleted` = '0'
AND  `empfirstname` LIKE '%%' ESCAPE '!'
ERROR - 2019-09-18 10:19:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:19:10 --> Query error: Unknown column 'empfirstname' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblemp` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_deleted` = '0'
AND  `empfirstname` LIKE '%%' ESCAPE '!'
ERROR - 2019-09-18 10:29:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\payroll\admin\application\controllers\Employee.php 28
ERROR - 2019-09-18 10:30:55 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 10:30:55 --> Severity: Notice --> Undefined variable: employeeData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 164
ERROR - 2019-09-18 10:30:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:31:06 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:31:15 --> Query error: Unknown column 'empfirstname' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblemp` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`Is_deleted` = '0'
AND  `empfirstname` LIKE '%%' ESCAPE '!'
ERROR - 2019-09-18 10:31:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:31:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:31:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:32:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:32:48 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:32:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:32:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:33:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:35:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:35:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:35:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:37:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:37:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:37:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:37:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:38:37 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:38:42 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:38:58 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:39:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:39:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:39:05 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:39:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:40:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:40:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:41:38 --> Query error: Unknown column 't1.isdelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-18 10:42:53 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 10:42:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:43:00 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 10:43:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:43:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:43:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:44:54 --> Query error: Unknown column 't1.isdelete' in 'where clause' - Invalid query: SELECT `t1`.*, `t2`.`companyname`
FROM `tblhr` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`isdelete` = '0'
ERROR - 2019-09-18 10:48:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:48:46 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 10:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 10:48:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 10:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 10:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 10:48:56 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:48:56 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 10:52:20 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 10:52:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:52:21 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 10:52:21 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:52:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:52:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:52:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:53:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:53:06 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:53:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:53:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:54:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:54:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 10:54:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:54:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:54:32 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:54:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:55:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:55:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:55:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:55:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:56:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:56:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:58:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:58:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 10:58:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:02:15 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:02:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:02:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 11:02:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 11:02:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:03:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:03:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:03:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:05:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:05:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 11:06:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:06:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:06:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:06:59 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:06:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:07:18 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:07:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:07:26 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:07:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:07:57 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:07:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:07:59 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:07:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:07:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 11:08:10 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employelist.php 106
ERROR - 2019-09-18 11:08:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:08:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:08:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:09:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:09:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 11:09:38 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:09:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:14:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:14:54 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 315
ERROR - 2019-09-18 11:14:54 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\admin\application\views\Leave\leaves.php 945
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 11:14:54 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-18 12:29:07 --> 404 Page Not Found: Leave/Leaveadd
ERROR - 2019-09-18 12:29:10 --> 404 Page Not Found: Holiday/index
ERROR - 2019-09-18 12:29:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:29:58 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:29:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:30:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:30:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:30:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:30:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:30:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:30:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:30:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:31:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:35:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:38:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:38:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:38:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:38:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:38:29 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 12:38:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-18 12:40:14 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:40:14 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 12:40:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:41:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:41:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:41:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:41:32 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:41:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:41:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:42:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:42:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:42:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:42:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:42:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:43:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:43:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:43:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:43:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:43:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:44:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:44:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:44:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:44:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:44:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:44:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:46:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:46:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:46:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:46:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:46:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 12:46:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:46:33 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:46:33 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:46:33 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:46:46 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:46:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:46:46 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:46:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:48:59 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:48:59 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:48:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:48:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:49:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:49:13 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:49:13 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 12:53:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:53:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 12:55:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:55:41 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 12:55:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:55:48 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:55:52 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employeadd.php 197
ERROR - 2019-09-18 12:55:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:55:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:55:57 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employeadd.php 197
ERROR - 2019-09-18 12:55:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:56:31 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Employee\employeadd.php 197
ERROR - 2019-09-18 12:56:31 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:56:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:56:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:56:50 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:56:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 12:57:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:59:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:59:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 12:59:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:00:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:00:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:00:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:00:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:00:50 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:00:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:01:21 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 13:01:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:01:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 13:01:38 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:38 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 13:01:47 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 13:01:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:47 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 13:01:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:01:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:02:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:02:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:02:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:03:37 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:03:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:07:37 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:07:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:08:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:08:48 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:08:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:10:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:10:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:10:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:11:23 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:12:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:12:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:12:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:12:44 --> Severity: Notice --> Use of undefined constant ACTIVE - assumed 'ACTIVE' C:\xampp\htdocs\payroll\admin\application\controllers\Leave.php 111
ERROR - 2019-09-18 13:12:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:21:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:23:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:23:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:25:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:26:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:27:38 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:28:53 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 101
ERROR - 2019-09-18 13:28:53 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 163
ERROR - 2019-09-18 13:28:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:31:44 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 98
ERROR - 2019-09-18 13:31:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:32:10 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 98
ERROR - 2019-09-18 13:32:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:33:07 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 61
ERROR - 2019-09-18 13:33:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:33:13 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 98
ERROR - 2019-09-18 13:33:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:34:01 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 13:34:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:34:52 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 13:34:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:35:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 13:47:55 --> Severity: Notice --> Undefined property: Holiday::$Company_model C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:51:39 --> Severity: Notice --> Undefined property: Holiday::$Company_model C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:53:17 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 132
ERROR - 2019-09-18 13:53:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:54:24 --> Severity: Notice --> Undefined property: Holiday::$holiday_model C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 61
ERROR - 2019-09-18 13:54:45 --> Query error: Unknown column 'company_id' in 'where clause' - Invalid query: SELECT *
FROM `tblcmpholiday`
WHERE `Is_deleted` = '0'
AND `company_id` = '1'
ORDER BY `holiday_id` DESC
ERROR - 2019-09-18 13:55:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 13:56:00 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 29
ERROR - 2019-09-18 13:56:00 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 33
ERROR - 2019-09-18 13:56:00 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 37
ERROR - 2019-09-18 13:56:00 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 41
ERROR - 2019-09-18 13:56:00 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 45
ERROR - 2019-09-18 13:56:00 --> Query error: Column 'companyid' in order clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcmpholiday` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
ORDER BY `companyid` DESC
ERROR - 2019-09-18 13:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\payroll\admin\system\core\Exceptions.php:271) C:\xampp\htdocs\payroll\admin\system\core\Common.php 570
ERROR - 2019-09-18 13:57:05 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 29
ERROR - 2019-09-18 13:57:05 --> Query error: Column 'companyid' in order clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcmpholiday` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
ORDER BY `companyid` DESC
ERROR - 2019-09-18 13:57:44 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:57:44 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:57:44 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 21
ERROR - 2019-09-18 13:57:44 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 29
ERROR - 2019-09-18 13:57:44 --> Query error: Column 'companyid' in order clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcmpholiday` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
ORDER BY `companyid` DESC
ERROR - 2019-09-18 13:58:23 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:58:23 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:58:23 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 21
ERROR - 2019-09-18 13:58:23 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 29
ERROR - 2019-09-18 13:58:23 --> Query error: Column 'companyid' in order clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcmpholiday` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
ORDER BY `companyid` DESC
ERROR - 2019-09-18 13:58:58 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:58:58 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 13:58:58 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 21
ERROR - 2019-09-18 13:58:58 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\models\Holiday_model.php 29
ERROR - 2019-09-18 13:58:58 --> Query error: Column 'companyid' in order clause is ambiguous - Invalid query: SELECT `t1`.*, `t2`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcmpholiday` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
ORDER BY `companyid` DESC
ERROR - 2019-09-18 14:00:23 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:00:23 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:00:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:00:47 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:00:47 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:00:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:01:02 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:01:02 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:01:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:01:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:01:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:01:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:01:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:01:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:01:50 --> Severity: Notice --> Undefined variable: keyword C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 60
ERROR - 2019-09-18 14:06:28 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 14:06:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:06:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:09:30 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 14:09:31 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:09:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:10:41 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 14:10:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:10:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:11:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:11:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:11:19 --> 404 Page Not Found: Holiday/index
ERROR - 2019-09-18 14:12:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:20:49 --> Severity: Notice --> Undefined property: Holiday::$holiHoliday_modelay_model C:\xampp\htdocs\payroll\admin\application\controllers\Holiday.php 30
ERROR - 2019-09-18 14:21:21 --> Query error: Unknown column 'company_id' in 'field list' - Invalid query: INSERT INTO `tblcmpholiday` (`holidayday`, `holidaydate`, `holidayname`, `company_id`, `created_date`) VALUES ('', '1970-01-01', NULL, '1', '2019-09-18')
ERROR - 2019-09-18 14:22:05 --> Query error: Column 'holidayname' cannot be null - Invalid query: INSERT INTO `tblcmpholiday` (`holidayday`, `holidaydate`, `holidayname`, `companyid`, `created_date`) VALUES ('', '1970-01-01', NULL, '1', '2019-09-18')
ERROR - 2019-09-18 14:22:30 --> Query error: Column 'holidayname' cannot be null - Invalid query: INSERT INTO `tblcmpholiday` (`holidayday`, `holidaydate`, `holidayname`, `companyid`, `created_date`) VALUES ('', '1970-01-01', NULL, '1', '2019-09-18')
ERROR - 2019-09-18 14:22:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:22:37 --> Query error: Column 'holidayname' cannot be null - Invalid query: INSERT INTO `tblcmpholiday` (`holidayday`, `holidaydate`, `holidayname`, `companyid`, `created_date`) VALUES ('', '1970-01-01', NULL, '1', '2019-09-18')
ERROR - 2019-09-18 14:27:22 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 14:27:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:27:25 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Holiday\holidaylist.php 87
ERROR - 2019-09-18 14:27:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:27:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:28:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:28:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:28:32 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:28:38 --> 404 Page Not Found: Holiday/index
ERROR - 2019-09-18 14:29:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:30:14 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:30:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:30:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:30:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:30:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:30:38 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:31:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:31:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:31:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:31:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:32:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:34:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:35:20 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:33 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:35:39 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:37:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:37:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:38:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:38:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:38:37 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:39:39 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:40:05 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:40:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:43:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:45:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:45:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:47:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:47:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:47:58 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:49:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 79
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:52:29 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:52:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:53:43 --> Query error: Unknown column 'company_id' in 'where clause' - Invalid query: SELECT *
FROM `tblcmpleave`
WHERE `Is_deleted` = '0'
AND `company_id` = '1'
ORDER BY `leave_id` DESC
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 79
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 130
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayname C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 138
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidaydate C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 139
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holidayday C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 140
ERROR - 2019-09-18 14:54:04 --> Severity: Notice --> Undefined property: stdClass::$holiday_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 146
ERROR - 2019-09-18 14:54:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:55:35 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 79
ERROR - 2019-09-18 14:55:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:55:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 14:56:18 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 79
ERROR - 2019-09-18 14:56:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 14:56:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leave_name C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 128
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leavedays C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 129
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leave_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leave_name C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 128
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leavedays C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 129
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$leave_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:00:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:00:09 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:00:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:00:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leave_name C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 128
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leavedays C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 129
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leave_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leave_name C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 128
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leavedays C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 129
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$leave_id C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 132
ERROR - 2019-09-18 15:01:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:01:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\payroll\admin\application\views\Leave\leavelist.php 133
ERROR - 2019-09-18 15:01:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:01:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:03:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:03:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:03:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:09 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:04:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:04:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:04:55 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:05:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:05:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:05:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:05:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:05:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:05:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:06:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:07:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:07:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:07:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:08:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:08:08 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:08:08 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:10:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:10:28 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:10:28 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:10:48 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:10:48 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:10:48 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:11:46 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:11:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:11:46 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:13:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:13:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:13:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:13:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 285
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 285
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 287
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 287
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 289
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 289
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: now C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 285
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 285
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 287
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 287
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 289
ERROR - 2019-09-18 15:14:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 289
ERROR - 2019-09-18 15:14:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:14:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:14:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:14:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:14:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:14:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:14:43 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:14:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 15:15:15 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 15:15:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:15:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:12 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:17:12 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:17:15 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 15:17:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:19:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:19:04 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:19:04 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:19:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:19:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 15:19:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 15:19:05 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 15:19:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 15:21:13 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:21:13 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:21:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 15:21:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:21:15 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 15:21:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 16:45:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:48:14 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:48:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:23 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:42 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:49:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 16:50:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:50:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:50:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:51:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:51:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:51:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 16:51:36 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:52:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:52:42 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:52:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:54:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:54:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:55:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:55:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:58:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:59:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 16:59:46 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 16:59:46 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 16:59:46 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 16:59:46 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 16:59:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:00:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:02:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:02:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:02:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:03:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:04:03 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:04:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:04:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:05:28 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 17:05:28 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 17:05:28 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 17:05:28 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 17:05:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:05:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:05:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:05:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:05:32 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:10:46 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 17:10:46 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 17:10:46 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 17:10:46 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 17:10:46 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:10:47 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:10:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:10:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:10:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:11:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:11:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:11:02 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:11:02 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:11:47 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 17:11:47 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 17:11:47 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 17:11:47 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 17:11:48 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:11:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:11:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:11:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:11:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:13:01 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 17:13:01 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 17:13:01 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 17:13:01 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 17:13:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:13:01 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:13:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:13:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:13:02 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:13:22 --> Severity: Notice --> Undefined index: Companydocumentid C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 38
ERROR - 2019-09-18 17:13:22 --> Severity: Notice --> Undefined index: Documenttitle C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 39
ERROR - 2019-09-18 17:13:22 --> Severity: Notice --> Undefined index: Notificationdescription C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 40
ERROR - 2019-09-18 17:13:22 --> Severity: Notice --> Undefined index: Documentfile C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 41
ERROR - 2019-09-18 17:13:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:13:33 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:13:33 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:13:33 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:13:33 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:16:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:16:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:16:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:16:03 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:16:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:18:52 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:19:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:19:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:20:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 17:20:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:20:07 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 17:20:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:20:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:21:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:22:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:22:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:22:50 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:23:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:23:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:23:30 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:23:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:35:24 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:35:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:47:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:47:27 --> Query error: Unknown column 'assets' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*, `t5`.*, `t6`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
LEFT JOIN `tblcompanycompliances` as `t3` ON `t1`.`companyid` = `assets`
LEFT JOIN `tblstate` as `t4` ON `t1`.`stateid` = `t4`.`stateid`
LEFT JOIN `tblcompanynotification` as `t5` ON `t1`.`companyid` = `t5`.`companyid`
LEFT JOIN `tblcomnotdocument` as `t6` ON `t5`.`Companynotificationid` = `t6`.`Companynotificationid`
WHERE `t1`.`companyid` = 'assets'
ERROR - 2019-09-18 17:47:27 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:47:27 --> Query error: Unknown column 'app-assets' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*, `t5`.*, `t6`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
LEFT JOIN `tblcompanycompliances` as `t3` ON `t1`.`companyid` = `app-assets`
LEFT JOIN `tblstate` as `t4` ON `t1`.`stateid` = `t4`.`stateid`
LEFT JOIN `tblcompanynotification` as `t5` ON `t1`.`companyid` = `t5`.`companyid`
LEFT JOIN `tblcomnotdocument` as `t6` ON `t5`.`Companynotificationid` = `t6`.`Companynotificationid`
WHERE `t1`.`companyid` = 'app-assets'
ERROR - 2019-09-18 17:47:27 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:47:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:47:29 --> Query error: Unknown column 'app-assets' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*, `t5`.*, `t6`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
LEFT JOIN `tblcompanycompliances` as `t3` ON `t1`.`companyid` = `app-assets`
LEFT JOIN `tblstate` as `t4` ON `t1`.`stateid` = `t4`.`stateid`
LEFT JOIN `tblcompanynotification` as `t5` ON `t1`.`companyid` = `t5`.`companyid`
LEFT JOIN `tblcomnotdocument` as `t6` ON `t5`.`Companynotificationid` = `t6`.`Companynotificationid`
WHERE `t1`.`companyid` = 'app-assets'
ERROR - 2019-09-18 17:47:29 --> Query error: Unknown column 'assets' in 'on clause' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*, `t5`.*, `t6`.*
FROM `tblcompany` as `t1`
LEFT JOIN `tblcompanytype` as `t2` ON `t1`.`companytypeid` = `t2`.`companytypeid`
LEFT JOIN `tblcompanycompliances` as `t3` ON `t1`.`companyid` = `assets`
LEFT JOIN `tblstate` as `t4` ON `t1`.`stateid` = `t4`.`stateid`
LEFT JOIN `tblcompanynotification` as `t5` ON `t1`.`companyid` = `t5`.`companyid`
LEFT JOIN `tblcomnotdocument` as `t6` ON `t5`.`Companynotificationid` = `t6`.`Companynotificationid`
WHERE `t1`.`companyid` = 'assets'
ERROR - 2019-09-18 17:47:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:47:29 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:47:31 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:47:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:51:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:51:17 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:51:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:51:17 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:51:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:51:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:51:20 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:51:21 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:51:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:52:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:52:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:52:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:52:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:52:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:52:56 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:53:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:53:53 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:53:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:53:54 --> 404 Page Not Found: Default/ckeditor
ERROR - 2019-09-18 17:54:40 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:54:40 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:54:40 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:54:41 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:55:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:55:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:55:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:55:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:55:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:55:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:56:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 17:56:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:03 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:56:03 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:56:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:56:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:56:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:17 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:56:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 17:56:25 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 17:56:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 17:56:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 17:56:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 18:07:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:07:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 18:07:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 18:07:19 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 18:07:19 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 18:07:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 18:13:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:13:43 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 18:13:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 18:13:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 18:13:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 18:14:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:14:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 18:14:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:14:40 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:14:40 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:14:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:14:49 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:14:49 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:15:56 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:15:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:15:56 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 18:16:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 18:16:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:16:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:19:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:19:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 18:19:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:00:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:00:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:00:49 --> Severity: Notice --> Undefined index: companyimage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 373
ERROR - 2019-09-18 19:00:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:00:57 --> Severity: Notice --> Undefined index: companyimage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 373
ERROR - 2019-09-18 19:00:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:01:59 --> Severity: Notice --> Undefined index: companyimage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 373
ERROR - 2019-09-18 19:01:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:04:18 --> Severity: Notice --> Undefined index: companyimage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 373
ERROR - 2019-09-18 19:04:18 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:04:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:04:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:04:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:04:27 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:05:26 --> Severity: Notice --> Undefined index: companyimage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 363
ERROR - 2019-09-18 19:05:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:05:27 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:05:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:05:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:05:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:06:10 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 124
ERROR - 2019-09-18 19:06:10 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 137
ERROR - 2019-09-18 19:06:10 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:06:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:06:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:06:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:06:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:06:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:06:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:06:22 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:06:23 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:07:44 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 124
ERROR - 2019-09-18 19:07:44 --> Severity: Notice --> Undefined variable: companyimage C:\xampp\htdocs\payroll\admin\application\views\Company\companyadd.php 137
ERROR - 2019-09-18 19:07:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:07:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:07:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:07:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:07:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:08:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:08:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:08:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:08:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:08:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:11:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:11:44 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:11:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:24:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:24:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:24:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:24:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:24:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:24:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:24:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:25:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:25:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:31:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:31:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:33:12 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:33:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:33:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:33:23 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:33:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:33:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:35:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:35:01 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:35:01 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:42:31 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:42:31 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:42:31 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 149
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 161
ERROR - 2019-09-18 19:42:34 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:42:34 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:44:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:45:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Undefined variable: adminlist C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\Company\companylist.php 152
ERROR - 2019-09-18 19:47:11 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:47:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:47:23 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:47:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:47:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:47:23 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:47:49 --> Severity: Notice --> Undefined index: ProfileImage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 27
ERROR - 2019-09-18 19:47:50 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:48:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:48:40 --> 404 Page Not Found: Upload/company
ERROR - 2019-09-18 19:48:41 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:48:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:48:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:48:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:48:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:48:43 --> 404 Page Not Found: Upload/company
ERROR - 2019-09-18 19:48:58 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:48:58 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:48:58 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:49:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:49:26 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:49:26 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 19:49:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:49:29 --> 404 Page Not Found: Upload/company
ERROR - 2019-09-18 19:49:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:50:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:50:26 --> 404 Page Not Found: Upload/company
ERROR - 2019-09-18 19:50:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:50:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:50:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:51:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:51:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:52:16 --> Severity: Notice --> Undefined index: ProfileImage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 27
ERROR - 2019-09-18 19:52:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:52:57 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 19:52:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 19:53:14 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 19:53:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 19:53:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-18 19:53:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:28 --> Severity: Notice --> Undefined index: ProfileImage C:\xampp\htdocs\payroll\admin\application\controllers\Company.php 27
ERROR - 2019-09-18 19:53:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:53:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:54:00 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:54:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:54:00 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:55:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\admin\application\views\Company\profile.php 102
ERROR - 2019-09-18 19:55:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\admin\application\views\Company\profile.php 114
ERROR - 2019-09-18 19:55:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:55:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 19:55:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:55:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 19:55:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 19:56:14 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:56:41 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:56:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:57:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:57:32 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:58:07 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:58:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:58:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 19:58:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 19:59:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:00:02 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:00:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:00:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:00:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:00:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:00:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:01:33 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:01:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:02:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:02:32 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:02:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:03:33 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:04:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:04:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:04:42 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:05:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:05:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:05:24 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:05:34 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:05:34 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 20:05:34 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 20:05:58 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 20:05:58 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:05:58 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-18 20:08:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:08:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:10:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:10:17 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:10:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:10:29 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:14:19 --> Severity: Notice --> Undefined variable: comp C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 178
ERROR - 2019-09-18 20:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 178
ERROR - 2019-09-18 20:14:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:14:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:18:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:18:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:19:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:19:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:19:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:19:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:20:33 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:23:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:23:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:26:53 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:26:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 20:26:54 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 20:26:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:30:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:30:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:30:19 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 20:30:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:30:19 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 20:31:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:31:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:31:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-18 20:31:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-18 20:31:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-18 20:31:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:31:35 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:31:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:33:25 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:33:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:34:49 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:34:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:35:45 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 413
ERROR - 2019-09-18 20:35:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:35:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:36:06 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:36:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:36:21 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:36:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:39:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:40:01 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:40:26 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:40:30 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:46:34 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:46:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:47:16 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:49:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:49:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:51:22 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:55:47 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:55:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:56:38 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:56:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:56:43 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:56:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:58:59 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 20:58:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 20:59:06 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:00:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:00:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:03:27 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:03:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:09:13 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:09:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:09:28 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:09:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:09:40 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:09:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:13:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:13:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:14:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:14:31 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:14:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:15:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:15:37 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:15:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:15:45 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:16:08 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:17:54 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:17:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:18:15 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:18:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:18:57 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:18:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:19:39 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:19:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:20:00 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:20:04 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:20:19 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:20:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 21:20:51 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:20:51 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 21:20:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-18 21:24:53 --> 404 Page Not Found: Upload/admin
ERROR - 2019-09-18 21:24:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-18 21:24:54 --> 404 Page Not Found: Default/assets
