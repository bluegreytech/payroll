<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:32:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:32:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:32:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 07:32:16 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2019-08-28 07:33:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:33:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:33:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:33:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:34:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:34:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:34:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:34:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:35:04 --> 404 Page Not Found: Adminmaster/dashboard.php
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:35:21 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:35:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:35:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:35:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:35:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:36:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:21 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 07:36:24 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:31 --> 404 Page Not Found: Employeesphp/index
ERROR - 2019-08-28 07:36:37 --> 404 Page Not Found: Holidaysphp/index
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:36:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:05 --> 404 Page Not Found: Employeesphp/index
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 07:37:29 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:37:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:39:09 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:39:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:39:47 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:39:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:39:55 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:39:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:42:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:42:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:42:56 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-28 07:42:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:44:29 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 916
ERROR - 2019-08-28 07:44:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:47:14 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 916
ERROR - 2019-08-28 07:47:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:47:43 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 916
ERROR - 2019-08-28 07:47:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:50:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 07:50:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:50:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 07:50:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:52:57 --> Severity: Notice --> Undefined variable: data C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 875
ERROR - 2019-08-28 07:52:57 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 07:52:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:56:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 07:56:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 07:59:43 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 875
ERROR - 2019-08-28 08:00:22 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 875
ERROR - 2019-08-28 08:00:42 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 875
ERROR - 2019-08-28 08:00:42 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 08:00:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:02:27 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 933
ERROR - 2019-08-28 08:02:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:02:49 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 934
ERROR - 2019-08-28 08:02:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:03:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:03:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:03:32 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:03:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:03:47 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:03:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:03:52 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:03:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:03:57 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:03:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:04:47 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:04:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:04:48 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:04:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:04:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 08:04:49 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:04:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:04:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 08:04:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 08:04:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 08:04:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 10:39:46 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 10:39:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:40:47 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 10:41:11 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 935
ERROR - 2019-08-28 10:41:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:41:42 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 10:41:43 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 10:41:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:42:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 10:42:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:42:27 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 10:42:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:42:28 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 10:42:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:42:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 10:43:13 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 10:43:14 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 10:43:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:44:06 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 904
ERROR - 2019-08-28 10:44:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:44:32 --> 404 Page Not Found: Login/lout
ERROR - 2019-08-28 10:44:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 10:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 10:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 10:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 10:45:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 10:45:20 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 904
ERROR - 2019-08-28 10:45:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:45:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 904
ERROR - 2019-08-28 10:45:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:46:14 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:46:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:46:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:46:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:46:34 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:46:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:46:43 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:46:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:46:53 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:46:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:47:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 10:47:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:48:20 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 10:48:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:14:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:16:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:16:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:17:22 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:17:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:20:32 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:20:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:22:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 11:23:00 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:23:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:23:17 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:23:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:34:09 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:34:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:36:55 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:36:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:36:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:36:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:37:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:37:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:37:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 11:37:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:37:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:38:06 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:38:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:38:09 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 919
ERROR - 2019-08-28 11:38:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:38:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-28 11:38:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:38:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:38:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:38:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:38:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:38:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:41:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:41:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:41:44 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:41:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:41:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:41:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:43:33 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 920
ERROR - 2019-08-28 11:43:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:44:44 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:44:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:45:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:45:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:45:33 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:45:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:46:22 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:46:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:46:38 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:46:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:48:44 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:48:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:48:53 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:48:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:49:51 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:49:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:50:27 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:50:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:50:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:50:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:50:49 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:50:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:51:18 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:51:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:52:07 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:52:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:52:09 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:52:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:53:13 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:53:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:55:48 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:55:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:55:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:55:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:55:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:56:29 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:56:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:56:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:56:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 11:57:19 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 11:57:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:02:52 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:02:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:04:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:04:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:07:28 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:07:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:10:44 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:10:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:12:44 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:12:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:12:52 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:12:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:14:07 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:14:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:14:18 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 921
ERROR - 2019-08-28 12:14:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:15:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 12:16:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:16:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:16:36 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:16:54 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:16:54 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:18:42 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:18:42 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:20:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:20:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:20:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:20:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:28:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:28:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 12:29:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 12:29:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:12:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:12:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:13:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:13:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:16:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:16:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:16:20 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:16:20 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:16:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:16:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:16:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:16:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:16:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:16:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:17:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:17:10 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:17:26 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:17:26 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:20:15 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:20:15 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:21:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:21:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:21:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:21:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:22:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:22:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:22:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:22:48 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:24:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:24:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:25:29 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:25:29 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:28:46 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:28:46 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:29:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:29:03 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:29:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:29:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:41:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:41:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:41:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:41:31 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:41:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:41:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:41:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:42:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:42:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:43:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:44:25 --> 404 Page Not Found: Company/index
ERROR - 2019-08-28 13:44:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:44:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:44:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:44:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:44:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:45:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:50:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:51:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:51:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:52:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:52:20 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:52:20 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:52:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:52:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 13:52:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 13:52:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:53:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:55:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 13:58:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:05:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:06:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 14:06:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-28 14:06:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 14:06:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 14:07:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-28 14:07:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:07:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:08:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:18 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:09:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:10:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:27:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-28 14:28:11 --> 404 Page Not Found: Assets/img
