<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-20 05:56:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 05:57:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-20 05:57:01 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-20 05:57:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-20 05:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 05:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 05:57:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 05:57:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 05:57:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:04:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:13:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:35:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:47:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:48:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:49:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:51:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:51:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:53:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:54:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:56:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 06:56:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 06:56:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 06:56:29 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 06:57:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 06:57:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-20 07:12:16 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:12:25 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:12:39 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:17:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:17:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:17:17 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:17:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:17:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:17:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:17:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:17:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:18:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:18:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:18:46 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:18:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:19:01 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:19:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:19:08 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:19:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:19:08 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:19:32 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:19:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:19:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:19:44 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:19:50 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 07:20:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:20:03 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:20:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:20:03 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:21:55 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:21:55 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:21:55 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:21:55 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:22:53 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:22:53 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:22:53 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:22:53 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:23:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:23:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:23:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:23:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:24:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:24:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:24:29 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:24:29 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:24:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:24:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:24:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:24:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:29:32 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:29:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:29:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:29:32 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:29:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:29:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:29:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:29:43 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:30:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:30:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:30:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:30:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:39:11 --> 404 Page Not Found: Invoice/get_state
ERROR - 2019-09-20 07:51:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:51:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 07:51:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:51:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:53:32 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 07:53:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:53:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 07:53:32 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:09:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:09:46 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:09:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:09:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:10:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:10:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:10:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:10:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:16:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:16:13 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:16:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:16:13 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:16:23 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:16:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:16:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:16:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:19:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:19:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:19:06 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:19:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:20:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:20:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:20:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:20:08 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:22:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 145
ERROR - 2019-09-20 08:26:04 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 66
ERROR - 2019-09-20 08:26:04 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 84
ERROR - 2019-09-20 08:30:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:30:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:30:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:30:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:31:02 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:31:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:31:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:31:02 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:37:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:37:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:37:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 08:37:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:37:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 08:37:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:37:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 08:37:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:05:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 09:05:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-20 09:05:14 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-20 09:05:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-20 09:05:20 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 105
ERROR - 2019-09-20 09:05:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\admin\application\controllers\Login.php 47
ERROR - 2019-09-20 09:05:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 09:05:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 09:05:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 09:05:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-20 09:09:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:09:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:09:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:09:04 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:09:40 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:09:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:09:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:09:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:09:45 --> Severity: error --> Exception: Too few arguments to function Invoice::gethr(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 142
ERROR - 2019-09-20 09:12:43 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:12:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:12:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:12:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:15:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:15:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:15:38 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:15:38 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:16:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:16:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:16:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:16:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:16:43 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:16:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:16:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:16:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:16:59 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:17:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:17:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:17:00 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:17:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:17:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:17:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:17:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:21:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:21:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:21:37 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:21:37 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:22:31 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:22:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:22:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:22:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:22:51 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 09:22:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 09:22:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 09:22:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 11:13:24 --> Severity: Notice --> Undefined variable: Companyinvoiceid C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 84
ERROR - 2019-09-20 11:13:24 --> Query error: Not unique table/alias: 't2' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`companyid` IS NULL
ERROR - 2019-09-20 11:15:31 --> Severity: Notice --> Undefined variable: Companyinvoiceid C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 84
ERROR - 2019-09-20 11:15:31 --> Query error: Not unique table/alias: 't2' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`companyid` IS NULL
ERROR - 2019-09-20 11:16:31 --> Query error: Not unique table/alias: 't2' - Invalid query: SELECT `t1`.*, `t2`.*, `t3`.*, `t4`.*
FROM `tblcompanyinvoice` as `t1`
LEFT JOIN `tblcompany` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
LEFT JOIN `tblhr` as `t2` ON `t1`.`companyid` = `t2`.`companyid`
WHERE `t1`.`companyid` = '1'
ERROR - 2019-09-20 11:17:08 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:17:13 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:18:04 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:20:04 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:21:35 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:24:01 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:24:04 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:24:50 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:24:56 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 86
ERROR - 2019-09-20 11:27:54 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:28:29 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:28:42 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:28:50 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:29:22 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:29:29 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:31:53 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:32:21 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:33:28 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:33:28 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:33:34 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:34:12 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 87
ERROR - 2019-09-20 11:48:25 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 98
ERROR - 2019-09-20 11:48:25 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 99
ERROR - 2019-09-20 11:48:25 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 100
ERROR - 2019-09-20 11:48:25 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 101
ERROR - 2019-09-20 11:49:06 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 98
ERROR - 2019-09-20 11:49:06 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 99
ERROR - 2019-09-20 11:49:06 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 100
ERROR - 2019-09-20 11:49:06 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 101
ERROR - 2019-09-20 11:49:49 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 98
ERROR - 2019-09-20 11:49:49 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 99
ERROR - 2019-09-20 11:49:49 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 100
ERROR - 2019-09-20 11:49:49 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 101
ERROR - 2019-09-20 11:54:54 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 92
ERROR - 2019-09-20 11:55:40 --> Severity: Notice --> Undefined variable: paymentopt C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 92
ERROR - 2019-09-20 12:02:27 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-20 13:18:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\payroll\admin\application\views\Invoice\add-invoice.php 92
ERROR - 2019-09-20 13:39:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 13:39:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 13:39:57 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 13:39:58 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 13:42:27 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 13:42:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 13:42:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 13:42:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 14:00:25 --> Severity: error --> Exception: Too few arguments to function Invoice::edit_invoice(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 81
ERROR - 2019-09-20 14:02:42 --> Severity: error --> Exception: Too few arguments to function Invoice::edit_invoice(), 0 passed in C:\xampp\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\payroll\admin\application\controllers\Invoice.php 81
ERROR - 2019-09-20 14:09:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 14:09:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 14:09:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 14:09:26 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 14:09:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-20 14:09:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 14:09:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-20 14:09:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-20 14:29:30 --> 404 Page Not Found: Assets/img
