<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-26 11:10:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-26 11:10:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-26 11:10:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-26 11:10:58 --> 404 Page Not Found: Default/images
ERROR - 2019-07-26 11:10:58 --> 404 Page Not Found: Default/images
ERROR - 2019-07-26 11:10:58 --> 404 Page Not Found: Program/app-assets
