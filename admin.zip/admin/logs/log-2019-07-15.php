ERROR - 2019-07-15 11:46:08 --> 404 Page Not Found: Home/index
ERROR - 2019-07-15 11:46:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:46:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-15 11:46:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-15 11:46:41 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-07-15 11:46:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:49:48 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-07-15 11:49:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:51:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:51:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:51:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-15 11:51:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-15 11:51:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-15 11:51:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-15 11:51:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-15 11:51:47 --> 404 Page Not Found: Program/app-assets
