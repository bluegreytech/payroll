<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-23 14:00:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-23 14:00:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-23 14:00:04 --> 404 Page Not Found: Login/change_password
ERROR - 2019-08-23 14:00:16 --> 404 Page Not Found: Login/change_password
ERROR - 2019-08-23 14:00:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:00:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:00:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:00:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:00:32 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:00:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-23 14:01:00 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-23 14:01:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-23 14:01:05 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-23 14:01:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-23 14:01:17 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-23 14:01:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:01:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:01:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:01:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-23 14:01:45 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-23 14:01:45 --> 404 Page Not Found: Default/cdn-cgi
