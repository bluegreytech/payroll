
		<!-- jQuery -->
        <script src="<?php echo base_url(); ?>default/js/jquery-3.2.1.min.js"></script>

		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>default/js/popper.min.js"></script>
        <script src="<?php echo base_url(); ?>default/js/bootstrap.min.js"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url(); ?>default/js/jquery.slimscroll.min.js"></script>
		
		<!-- Chart JS -->

		<script src="<?php echo base_url(); ?>default/plugins/morris/morris.min.js"></script>
		<script src="<?php echo base_url(); ?>default/plugins/raphael/raphael.min.js"></script>
		<script src="<?php echo base_url(); ?>default/js/chart.js"></script>

		<!-- Select2 JS -->
		<script src="<?php echo base_url(); ?>default/js/select2.min.js"></script>
		
		<!-- Datetimepicker JS -->
		<script src="<?php echo base_url(); ?>default/js/moment.min.js"></script>
		<script src="<?php echo base_url(); ?>default/js/bootstrap-datetimepicker.min.js"></script>
			
		<!-- Tagsinput JS -->
		<script src="<?php echo base_url(); ?>default/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
		<script src="<?php echo base_url(); ?>default/js/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url(); ?>default/js/dataTables.bootstrap4.min.js"></script>

		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>default/js/app.js"></script>

		<script type="text/javascript" src="<?php echo base_url(); ?>default/js/jquery.validate.min.js"></script>
		<script src="<?php echo base_url(); ?>default/js/additional-methods.min.js"></script>
 			
		<script src="<?php echo base_url(); ?>default/js/moment.js" type="text/javascript" ></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

		</body>
</html>