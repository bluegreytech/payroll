<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:35 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:36 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:12:36 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-26 14:12:44 --> 404 Page Not Found: Login/change_password
ERROR - 2019-08-26 14:12:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:13:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:13:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:13:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:13:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:13:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:37:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-26 14:37:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:38:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-26 14:38:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-26 14:38:30 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:33 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:38 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:41 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:49 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:51 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:57 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:38:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:38:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:39:05 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:39:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:40:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-26 14:40:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-26 14:43:14 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
