<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-06 06:43:39 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 06:44:47 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 06:44:47 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 06:44:47 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 06:44:47 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 06:44:47 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 06:44:47 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 06:44:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 06:44:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 06:49:21 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 06:49:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 06:53:51 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 06:53:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 06:54:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 06:56:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 06:57:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 07:01:39 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:02:13 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:03:03 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:05:50 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:06:46 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:07:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:07:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:08:25 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 07:08:31 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 07:08:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:22 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 101
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 113
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 114
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'PhoneNumber' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 123
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 131
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'UserId' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:54 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:54 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-06 07:09:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:09:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:10:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:13:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:13:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:26:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:27:27 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:27:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:53:39 --> 404 Page Not Found: Searchhtml/index
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:42 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:53:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:55:40 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:55:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 248
ERROR - 2019-09-06 07:56:11 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 249
ERROR - 2019-09-06 07:56:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 230
ERROR - 2019-09-06 08:01:25 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 231
ERROR - 2019-09-06 08:01:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:03:36 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:03:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 232
ERROR - 2019-09-06 08:04:01 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:04:59 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:05:41 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:05:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:09:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:09:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 233
ERROR - 2019-09-06 08:12:49 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 234
ERROR - 2019-09-06 08:12:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 165
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:19:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 253
ERROR - 2019-09-06 08:19:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 165
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 176
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 250
ERROR - 2019-09-06 08:19:52 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:19:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:19:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:19:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:19:57 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 166
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 177
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:13 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:26:14 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:26:14 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:26:14 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:26:53 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:26:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:26:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:26:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:26:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:27:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:27:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:27:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:27:48 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:27:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:27:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:27:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:27:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:12 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:29:13 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:29:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:29:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:29:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:29:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:29:22 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:29:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:29:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:02 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:30:03 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:30:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:30:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 251
ERROR - 2019-09-06 08:30:18 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 252
ERROR - 2019-09-06 08:30:19 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:30:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:30:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:30:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:32:09 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:32:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:32:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:32:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:32:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:32:23 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:32:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:32:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:32:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:32:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:34:08 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:34:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:34:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:34:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:34:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:34:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:34:09 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:35:28 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:35:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:35:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:35:29 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:35:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:35:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:35:29 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:37:37 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 92
ERROR - 2019-09-06 08:37:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:37:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:37:38 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:37:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:37:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:37:38 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:38:28 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:38:29 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:39:18 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 08:39:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:39:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:39:19 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:39:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:39:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:39:19 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:41:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:41:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:41:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:41:35 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:41:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:41:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:41:35 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:20 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:42:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 246
ERROR - 2019-09-06 08:42:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 247
ERROR - 2019-09-06 08:42:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:42:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:42:32 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:42:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:42:33 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:42:33 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:43:33 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:43:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:43:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:43:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:43:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:43:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:43:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:45:04 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:45:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:45:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:45:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:45:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:45:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:45:05 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 243
ERROR - 2019-09-06 08:46:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 244
ERROR - 2019-09-06 08:46:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:46:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:46:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:46:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:46:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:46:17 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:47:00 --> 404 Page Not Found: Hr/index
ERROR - 2019-09-06 08:47:21 --> 404 Page Not Found: Hr/index
ERROR - 2019-09-06 08:47:22 --> 404 Page Not Found: Hr/index
ERROR - 2019-09-06 08:47:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 08:47:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 08:47:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 08:47:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:47:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 08:47:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 08:47:26 --> Severity: error --> Exception: Call to undefined method Hr_model::hrlist() C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 65
ERROR - 2019-09-06 09:01:40 --> Severity: error --> Exception: Call to undefined method Hr_model::hrlist() C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 65
ERROR - 2019-09-06 09:01:49 --> Severity: error --> Exception: Call to undefined method Hr_model::hrlist() C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 65
ERROR - 2019-09-06 09:01:56 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tblhr`
WHERE `is_deleted` = '0'
ERROR - 2019-09-06 09:04:09 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 09:04:09 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 237
ERROR - 2019-09-06 09:04:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:04:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:04:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:04:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:04:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:04:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:08:16 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 237
ERROR - 2019-09-06 09:08:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:08:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:08:16 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:08:16 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:17 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:08:38 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 237
ERROR - 2019-09-06 09:08:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:08:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:08:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:08:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:08:47 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 237
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:08:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:09:06 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 238
ERROR - 2019-09-06 09:09:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:09:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:09:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:09:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:09:22 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 238
ERROR - 2019-09-06 09:09:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:09:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:09:23 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:09:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:09:43 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:09:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:09:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:09:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:09:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:09:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:10:34 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 66
ERROR - 2019-09-06 09:10:47 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 66
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 86
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:18 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:11:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:11:18 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:18 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:11:19 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:11:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:19 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:32 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:11:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:11:32 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:32 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:11:33 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:11:33 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:33 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:33 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$FullnName C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 100
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:36 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:11:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:11:36 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:36 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:11:37 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:11:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:37 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$PhoneNumber C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:11:49 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:11:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:11:49 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:49 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:11:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:11:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:11:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:11:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$companyname C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:03 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:12:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:12:03 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:03 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:12:04 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:12:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$Status C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$Status C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:10 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:12:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:12:10 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:10 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:12:11 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:12:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:11 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:12:17 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:17 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:17 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:17 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 128
ERROR - 2019-09-06 09:12:17 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:12:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:12:17 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:17 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:12:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:12:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:12:30 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:30 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 126
ERROR - 2019-09-06 09:12:30 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:12:42 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:12:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:12:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:13:22 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:13:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:13:22 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:13:22 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:13:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:13:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:13:23 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:13:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:13:23 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:13:23 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:13:48 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:13:48 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:13:48 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:13:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:13:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:13:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:13:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:13:53 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:13:53 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:14:01 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:14:01 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:14:01 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:14:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:14:13 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:14:13 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:14:13 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:14:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:17:04 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:17:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:17:04 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:17:04 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:17:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:18:17 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:18:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:18:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-09-06 09:18:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-09-06 09:18:18 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:18:18 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-09-06 09:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2019-09-06 09:18:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:18:59 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:18:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:18:59 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:18:59 --> 404 Page Not Found: Uploads/hr
ERROR - 2019-09-06 09:19:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:19:31 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:19:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:19:31 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:19:31 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:19:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:19:44 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:19:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:19:44 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:19:44 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:19:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:19:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:20:04 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:20:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:20:04 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:20:04 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 09:20:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:23:53 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:23:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:23:54 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:23:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:24:28 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:24:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:24:29 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:24:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:24:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:25:46 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:25:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:25:46 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:25:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:26:01 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:26:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:26:01 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:26:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:26:18 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:26:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:26:18 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:26:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:26:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:26:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:26:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:26:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:26:25 --> 404 Page Not Found: Upload/no_image
ERROR - 2019-09-06 09:26:43 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:26:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:26:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:26:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:26:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:26:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:26:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:27:10 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:27:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:27:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:27:20 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:27:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:27:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:27:45 --> 404 Page Not Found: Hr/index
ERROR - 2019-09-06 09:27:46 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 240
ERROR - 2019-09-06 09:27:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:28:22 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 237
ERROR - 2019-09-06 09:28:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:28:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:29:17 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 238
ERROR - 2019-09-06 09:29:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:29:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:29:42 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:29:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:29:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:30:09 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:30:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:30:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:30:17 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 239
ERROR - 2019-09-06 09:30:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:30:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:31:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:31:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:36:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:36:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:38:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 09:38:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:38:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:38:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:38:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:38:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:38:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:39:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:39:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:40:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:40:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:41:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:42:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:42:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:43:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:43:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:44:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:44:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:44:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:44:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:44:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:44:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:44:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:44:41 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:45:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:45:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:45:04 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:45:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:45:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:45:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:45:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:45:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:45:57 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:45:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:45:57 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:45:58 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:46:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:46:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:46:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:46:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:46:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:46:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:47:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:47:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:47:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:47:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:47:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:47:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:47:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:47:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:48:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:48:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:48:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:48:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:48:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:48:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:49:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:49:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:49:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:49:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:49:43 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:49:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:49:43 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:50:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:50:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:50:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:50:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:50:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:50:12 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:50:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:12 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:50:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:50:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:50:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:50:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:50:49 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:51:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:51:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:51:02 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:51:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:51:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:51:03 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:51:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:51:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:51:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:51:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:51:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:51:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:53:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:53:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:53:11 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 09:53:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:53:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 09:53:11 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 09:53:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:53:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:54:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:54:22 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 09:54:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 09:54:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:37:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:37:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:37:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:37:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:37:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:37:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:41:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:41:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:43:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:43:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:43:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:43:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:45:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:45:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:45:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:45:41 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:46:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:46:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:46:16 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:46:16 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:46:16 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:46:16 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:46:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:46:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:46:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:46:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:46:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:46:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:47:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:47:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:47:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:47:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:47:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:47:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:48:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:48:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:48:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:48:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:48:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:48:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:48:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:48:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:49:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:49:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:49:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:49:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:49:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:49:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:50:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:50:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:50:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:50:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:50:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:50:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:50:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:50:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:50:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:50:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:50:31 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:50:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:50:32 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:52:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:53:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:53:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:53:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:53:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:53:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:56:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:56:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:56:59 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:56:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:00 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:57:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:57:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:57:14 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:57:14 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:14 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:57:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:57:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:57:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:57:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:57:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:57:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:57:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:57:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 10:57:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 11:00:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:00:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:00:04 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 11:00:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:00:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:00:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 11:02:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:04:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:05:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:20:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:21:14 --> Query error: Unknown column 'City' in 'field list' - Invalid query: INSERT INTO `tblhr` (`EmailAddress`, `FullName`, `ProfileImage`, `Address`, `Contact`, `Gender`, `DateofBirth`, `City`, `PinCode`, `companyid`, `CreatedOn`) VALUES ('veer@yopmail.com', 'veer', '57Admin.jpg', 'sama road', NULL, 'Male', '1985-05-02', 'anand', '123456', '1', '2019-09-06')
ERROR - 2019-09-06 11:21:39 --> Query error: Column 'Contact' cannot be null - Invalid query: INSERT INTO `tblhr` (`EmailAddress`, `FullName`, `ProfileImage`, `Address`, `Contact`, `Gender`, `DateofBirth`, `City`, `PinCode`, `companyid`, `CreatedOn`) VALUES ('veer@yopmail.com', 'veer', '9261Admin.jpg', 'sama road', NULL, 'Male', '1985-05-02', 'anand', '123456', '1', '2019-09-06')
ERROR - 2019-09-06 11:24:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:24:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:26:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:26:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:26:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:26:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:29:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:29:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:33:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:33:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:34:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:34:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:36:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:36:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:36:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:36:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:42:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:42:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:42:55 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:42:55 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:42:55 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 11:42:56 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 11:43:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:43:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:43:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 11:43:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:43:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 11:43:54 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 11:44:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:45:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:45:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:47:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:48:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:49:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:49:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:51:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:51:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:51:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:51:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:51:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:51:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:54:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:54:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:54:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:54:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:56:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:56:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:56:53 --> 404 Page Not Found: User/userlist
ERROR - 2019-09-06 11:57:05 --> 404 Page Not Found: User/userlist
ERROR - 2019-09-06 11:57:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:57:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:57:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:57:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:57:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:57:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:57:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:57:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:58:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:58:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 11:58:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 11:58:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:11:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:11:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:11:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:13:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:13:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:23:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:23:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:27:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:27:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:30:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:30:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:31:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:31:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:33:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:33:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:34:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:34:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:34:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:34:22 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:34:22 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 12:34:22 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 12:34:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:34:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:34:40 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 12:34:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:34:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:34:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 12:35:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:35:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:35:01 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 12:35:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:35:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:35:02 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 12:35:05 --> Severity: Warning --> Use of undefined constant ACTIVE - assumed 'ACTIVE' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 135
ERROR - 2019-09-06 12:35:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:35:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 12:35:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:35:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:35:06 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 12:35:11 --> Severity: Warning --> Use of undefined constant ACTIVE - assumed 'ACTIVE' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 135
ERROR - 2019-09-06 12:35:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:35:15 --> Severity: Warning --> Use of undefined constant ACTIVE - assumed 'ACTIVE' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 143
ERROR - 2019-09-06 12:35:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:36:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:36:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:36:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:36:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:36:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:36:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:37:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:37:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:38:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:38:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:39:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:39:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:39:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:39:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:39:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:39:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:42:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:42:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:46:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:46:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:46:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:46:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:49:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:49:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:53:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:53:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:54:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 12:54:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 12:55:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:55:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 12:55:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 12:55:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 12:55:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:01:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:01:36 --> Severity: Notice --> Undefined property: Hr::$Hr_model C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 103
ERROR - 2019-09-06 13:01:36 --> Severity: error --> Exception: Call to a member function gethrdata() on null C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 103
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\payroll\hr\application\models\Hr_model.php 409
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 107
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 108
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 109
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 110
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 111
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 112
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 113
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 114
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 115
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:01:43 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:01:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:01:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\payroll\hr\application\models\Hr_model.php 409
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 107
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 108
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 109
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 110
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 111
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 112
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 113
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 114
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 115
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:01:46 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:01:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:01:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:01:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:01:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\payroll\hr\application\models\Hr_model.php 409
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 107
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 108
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 109
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 110
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 111
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 112
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 113
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 114
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 115
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:01:57 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:02:37 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\payroll\hr\application\models\Hr_model.php 409
ERROR - 2019-09-06 13:02:37 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:02:49 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 107
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 108
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 109
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 110
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 111
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 112
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 113
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 114
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 115
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 116
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:05 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:03:06 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:03:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:03:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:03:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:03:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:03:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 107
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 108
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 110
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 111
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 112
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 113
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 114
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 115
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 116
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 97
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'FullName' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 109
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'EmailAddress' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 117
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'Contact' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 118
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 121
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'IsActive' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 122
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 133
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'hr_id' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Trying to get property 'ProfileImage' of non-object C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 135
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:03:10 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:03:49 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\controllers\Hr.php 106
ERROR - 2019-09-06 13:04:22 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 13:04:22 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:04:22 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:04:24 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 85
ERROR - 2019-09-06 13:04:24 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 167
ERROR - 2019-09-06 13:04:24 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampp\htdocs\payroll\hr\application\views\hr\hrlist.php 178
ERROR - 2019-09-06 13:04:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:04:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:04:25 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:04:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:04:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:04:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:05:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:05:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:05:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:05:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:10:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:10:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:10:15 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:10:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:10:15 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:10:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:10:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:10:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:10:26 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:10:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:10:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:10:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:12:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:13:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:13:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:13:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:13:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:13:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:13:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:13:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:13:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:13:51 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:14:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:14:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:14:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:14:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:14:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:14:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:14:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:14:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:14:52 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:14:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:14:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:14:52 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:15:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:15:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:15:06 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:15:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:15:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:15:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:15:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:15:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:15:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:15:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:16:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:16:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:17:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:17:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:17:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:17:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:18:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:18:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:18:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:18:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:19:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:19:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:20:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:20:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:21:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:21:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:23:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:23:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:23:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:23:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:23:12 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:23:13 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:23:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:23:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:23:30 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:23:30 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:23:30 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:23:30 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:24:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:24:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:24:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:24:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:24:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:24:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:24:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:28:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:28:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:28:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:28:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:28:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:28:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:28:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:28:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:28:45 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:28:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:29:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:29:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:29:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:29:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:29:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:29:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:30:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:30:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:30:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:30:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:30:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:30:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:31:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:31:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:31:10 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:31:18 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:33:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:33:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:34:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:34:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:34:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:34:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:34:38 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:35:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:35:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:35:28 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:35:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:35:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:35:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:35:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:35:46 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:36:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:36:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:36:20 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:36:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:20 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:36:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:36:27 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:36:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:36:42 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:36:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:36:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:36:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:37:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:37:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:37:29 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:38:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:38:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:39:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:39:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:39:38 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:39:40 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:39:45 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:39:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:39:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:39:49 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:39:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:40:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:40:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:40:26 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:40:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:40:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:40:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:41:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:41:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:41:11 --> 404 Page Not Found: Upload/hr
ERROR - 2019-09-06 13:42:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:42:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:49:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:49:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:50:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:50:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:50:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:50:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:50:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:50:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:50:35 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:50:36 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:51:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:51:34 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:51:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:51:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:51:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:51:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:56:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:56:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:56:45 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:56:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:56:45 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:56:45 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:57:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:57:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:57:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:57:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:57:09 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:57:09 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:57:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:57:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:57:27 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:57:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:57:27 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:57:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:58:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:58:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:58:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:58:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:58:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:58:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 13:58:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 13:58:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 13:58:26 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 13:58:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:58:26 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 13:58:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:01:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:01:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:01:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:01:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:01:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:01:49 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:02:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:02:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:02:16 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:02:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:02:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:02:17 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:02:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:02:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:02:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:02:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:02:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:02:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:05:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:05:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:05:03 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:05:03 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:05:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:05:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:05:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:05:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:05:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:05:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:05:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:05:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:08:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:08:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:08:04 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:08:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:08:04 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:08:04 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:14:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:14:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:14:36 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:14:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:14:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:14:36 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:15:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:15:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:15:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:15:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:15:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:15:06 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:16:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:16:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:16:51 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:16:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:16:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:16:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:17:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:17:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:17:49 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:17:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:17:49 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:17:49 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:18:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:18:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:18:10 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:18:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:18:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:18:10 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:19:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:02 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:19:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:19:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:19:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:19:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:25 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:19:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:19:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:19:51 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:19:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:19:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:20:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:20:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:24:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:24:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:26:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:26:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:27:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:27:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:27:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:27:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:28:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:13 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:28:14 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:28:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:28:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:28:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:28:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:19 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:28:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:29 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:29 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:28:29 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:28:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:28:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:28:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:28:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:28:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:29:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:29:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:29:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:29:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:29:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:29:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:29:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:29:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:29:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:29:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:29:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:29:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:30:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:30:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:30:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:30:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:30:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:30:39 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:30:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:30:39 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:30:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:30:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:30:47 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:30:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:30:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:30:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:31:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:31:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:31:13 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:31:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:31:13 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:31:13 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:31:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:31:54 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:31:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:31:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:31:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:31:54 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:32:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:32:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:32:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:32:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:32:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:32:08 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:32:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:33:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:33:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:33:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:33:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:33:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:33:06 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:33:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:33:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:34:28 --> Query error: Unknown column 'UpdateOn' in 'field list' - Invalid query: UPDATE `tblhr` SET `FullName` = 'archana1', `ProfileImage` = '6033Admin.jpg', `Address` = 'fathgunj', `Contact` = '0987654322', `Gender` = 'Male', `DateofBirth` = '1970-01-01', `City` = 'surat', `PinCode` = '123456', `companyid` = '1', `UpdateOn` = '2019-09-06'
WHERE `hr_id` = '7'
ERROR - 2019-09-06 14:34:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-06 14:34:39 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:44:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:44:32 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:44:32 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:44:33 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:44:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:42 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:44:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:44:42 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:44:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:44:54 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:44:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:44:54 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:01 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:45:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:01 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:45:09 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:45:09 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:45:09 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:09 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:09 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:09 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:09 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:10 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:35 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:45:35 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:45:35 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:35 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:35 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:35 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:36 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:45:37 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:37 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-06 14:45:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:37 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:37 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-06 14:45:50 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:45:50 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:45:50 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:50 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:50 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:50 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:51 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:58 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:45:58 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:45:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:00 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:46:00 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:46:00 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:00 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:00 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:00 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:01 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-06 14:46:01 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:01 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:02 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:46:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:02 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:18 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:18 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:18 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:18 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:46:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:46:19 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:27 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:27 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:27 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:27 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-06 14:46:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-06 14:46:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-06 14:46:28 --> 404 Page Not Found: Default/js
ERROR - 2019-09-06 14:46:28 --> 404 Page Not Found: Default/js
