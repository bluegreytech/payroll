<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-29 05:59:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 05:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:01:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 06:11:45 --> 404 Page Not Found: Client-profilephp/index
ERROR - 2019-08-29 06:33:16 --> Severity: Notice --> Undefined variable: companyname C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 66
ERROR - 2019-08-29 06:36:11 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 661
ERROR - 2019-08-29 06:39:20 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 82
ERROR - 2019-08-29 06:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:49:29 --> 404 Page Not Found: Default/uploads
ERROR - 2019-08-29 06:50:00 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:50:00 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:50:00 --> 404 Page Not Found: Default/uploads
ERROR - 2019-08-29 06:50:36 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:50:36 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:50:36 --> 404 Page Not Found: Default/uploads
ERROR - 2019-08-29 06:51:04 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:04 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:04 --> 404 Page Not Found: Uploads/default
ERROR - 2019-08-29 06:51:11 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:11 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:12 --> 404 Page Not Found: Uploads/default
ERROR - 2019-08-29 06:51:44 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:44 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:44 --> 404 Page Not Found: Admin/uploads
ERROR - 2019-08-29 06:51:53 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:53 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:51:53 --> 404 Page Not Found: Uploads/default
ERROR - 2019-08-29 06:52:08 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:08 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:08 --> 404 Page Not Found: Uploads/default
ERROR - 2019-08-29 06:52:18 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:18 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:18 --> 404 Page Not Found: Uploads/default
ERROR - 2019-08-29 06:52:50 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:51 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:51 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:52:51 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 65
ERROR - 2019-08-29 06:53:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 06:53:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 06:53:28 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 06:54:17 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 06:54:17 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 06:54:17 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 07:10:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:20 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 07:10:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 07:10:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 07:12:42 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 07:12:42 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 07:19:06 --> Query error: Column 'isactive' cannot be null - Invalid query: INSERT INTO `tblcompany` (`companyname`, `comemailaddress`, `comcontactnumber`, `gstnumber`, `companylogo`, `isactive`, `createdby`, `createdon`) VALUES ('fghfghgfh', 'mitnp16@gmail.com', '1111111111', '124123423523523', NULL, NULL, 1, '2019-08-29 07:19:06')
ERROR - 2019-08-29 07:39:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 07:39:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 07:56:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 07:56:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 07:56:54 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 07:58:15 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 07:58:16 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 07:58:16 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:00:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:00:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:00:22 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 08:19:11 --> 404 Page Not Found: Company/editcompanys
ERROR - 2019-08-29 08:21:56 --> 404 Page Not Found: Company/editcompanys
ERROR - 2019-08-29 08:23:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 08:23:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 08:23:06 --> 404 Page Not Found: Company/editcompanys
ERROR - 2019-08-29 08:28:56 --> Severity: error --> Exception: Call to undefined method Company_model::get_company() C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 69
ERROR - 2019-08-29 08:31:32 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:31:32 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:31:32 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 08:32:10 --> 404 Page Not Found: Default/css
ERROR - 2019-08-29 08:32:10 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 08:32:10 --> 404 Page Not Found: Default/js
ERROR - 2019-08-29 09:18:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 09:38:51 --> 404 Page Not Found: Company/companylist
ERROR - 2019-08-29 09:39:56 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 70
ERROR - 2019-08-29 09:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 70
ERROR - 2019-08-29 10:16:57 --> Severity: Notice --> Undefined variable: companyname C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 61
ERROR - 2019-08-29 10:16:57 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 67
ERROR - 2019-08-29 10:16:57 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 74
ERROR - 2019-08-29 10:16:57 --> Severity: Notice --> Undefined variable: gstnumber C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 80
ERROR - 2019-08-29 10:17:40 --> Severity: Notice --> Undefined variable: companyname C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 55
ERROR - 2019-08-29 10:17:40 --> Severity: Notice --> Undefined variable: comemailaddress C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 61
ERROR - 2019-08-29 10:17:40 --> Severity: Notice --> Undefined variable: comcontactnumber C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 68
ERROR - 2019-08-29 10:17:40 --> Severity: Notice --> Undefined variable: gstnumber C:\xampps\htdocs\payroll\admin\application\views\Company\companyadd.php 74
ERROR - 2019-08-29 10:52:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 10:52:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 10:52:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 10:52:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 10:58:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 10:58:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 10:58:48 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 10:58:48 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 10:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:06:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:08:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companylist.php 97
ERROR - 2019-08-29 11:14:32 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:26:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 11:26:08 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 11:26:45 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-29 11:26:45 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-29 11:28:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:28:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:33:44 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:34:16 --> Severity: Notice --> Undefined variable: companyData C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:34:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 70
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:35:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 11:49:03 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 59
ERROR - 2019-08-29 11:49:20 --> Severity: Notice --> Undefined property: stdClass::$IsActive C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 59
ERROR - 2019-08-29 11:49:20 --> Severity: Notice --> Undefined property: stdClass::$IsActive C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 59
ERROR - 2019-08-29 12:07:40 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:08:43 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:09:54 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:12:04 --> 404 Page Not Found: Company/get_companytype
ERROR - 2019-08-29 12:12:48 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:13:46 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 136
ERROR - 2019-08-29 12:13:49 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:15:03 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 136
ERROR - 2019-08-29 12:15:05 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:15:40 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 137
ERROR - 2019-08-29 12:15:41 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 137
ERROR - 2019-08-29 12:15:43 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 12:15:46 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:16:22 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 137
ERROR - 2019-08-29 12:16:24 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:16:45 --> Severity: Notice --> Undefined variable: companytypeid C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 137
ERROR - 2019-08-29 12:16:49 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 123
ERROR - 2019-08-29 12:23:09 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:25:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-29 12:25:55 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:27:02 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:28:12 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:37:44 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:39:28 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:39:45 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:39:51 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:40:54 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:41:00 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:57:30 --> 404 Page Not Found: Company/get_companytype
ERROR - 2019-08-29 12:58:02 --> 404 Page Not Found: Company/get_companytype
ERROR - 2019-08-29 12:58:04 --> 404 Page Not Found: Company/get_companytype
ERROR - 2019-08-29 12:58:47 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 50
ERROR - 2019-08-29 12:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 50
ERROR - 2019-08-29 12:59:10 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 12:59:57 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 13:05:23 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 13:05:27 --> Query error: Column 'isactive' cannot be null - Invalid query: INSERT INTO `tblcompanytype` (`companytype`, `isactive`, `createdby`, `createdon`) VALUES ('dfghdddddddddddddd', NULL, 1, '2019-08-29 01:05:27')
ERROR - 2019-08-29 13:20:38 --> Severity: error --> Exception: Too few arguments to function Company::editcompanytype(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Company.php 151
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 13:51:41 --> 404 Page Not Found: Default/im
ERROR - 2019-08-29 14:03:17 --> Severity: Notice --> Undefined variable: compliancename C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 45
ERROR - 2019-08-29 14:03:17 --> Severity: Notice --> Undefined variable: compliancepercentage C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 46
ERROR - 2019-08-29 14:03:17 --> Severity: Notice --> Undefined variable: isactive C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 47
ERROR - 2019-08-29 14:03:17 --> Severity: Notice --> Undefined variable: compliancename C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 45
ERROR - 2019-08-29 14:03:17 --> Severity: Notice --> Undefined variable: compliancepercentage C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 46
ERROR - 2019-08-29 14:03:18 --> Severity: Notice --> Undefined variable: isactive C:\xampps\htdocs\payroll\admin\application\views\compliance\compliance.php 47
ERROR - 2019-08-29 14:12:43 --> 404 Page Not Found: Compliance/index
ERROR - 2019-08-29 14:13:28 --> 404 Page Not Found: Compliance/index
ERROR - 2019-08-29 14:25:27 --> Severity: Notice --> Undefined variable: companytypeData C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 50
ERROR - 2019-08-29 14:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Company\companytypelist.php 50
