ERROR - 2019-09-04 12:21:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:21:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:28:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:28:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:29:44 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\payroll\admin\application\views\dashboard\profile.php 74
ERROR - 2019-09-04 12:29:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\payroll\admin\application\views\dashboard\profile.php 74
ERROR - 2019-09-04 12:30:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\payroll\admin\application\views\dashboard\profile.php 76
ERROR - 2019-09-04 12:30:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:30:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:30:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:30:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:30:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:30:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:31:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:31:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:31:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\payroll\admin\application\views\dashboard\profile.php 74
ERROR - 2019-09-04 12:31:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:31:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:32:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:32:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:32:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:32:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:32:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:32:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:32:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:32:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:33:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:33:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:33:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:33:30 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:33:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:33:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:34:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:34:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:34:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:34:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:35:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:35:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:35:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:35:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:38:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:38:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:38:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:39:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:39:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:39:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:40:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-04 12:40:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-04 12:40:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 105
ERROR - 2019-09-04 12:40:37 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-04 12:40:40 --> Query error: Table 'payrolldb.tblrights' doesn't exist - Invalid query: SELECT *
FROM `tblrights`
WHERE `isactive` = 1
ERROR - 2019-09-04 12:41:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 105
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:19 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-04 12:41:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampp\htdocs\payroll\admin\application\views\dashboard\adminlist.php 105
ERROR - 2019-09-04 12:41:34 --> 404 Page Not Found: Uploads/UserProfile
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 250
ERROR - 2019-09-04 12:41:43 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\admin\application\views\hr\hrlist.php 251
ERROR - 2019-09-04 12:41:43 --> 404 Page Not Found: Uploads/default
ERROR - 2019-09-04 12:42:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 12:44:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 12:47:00 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 12:47:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 25
ERROR - 2019-09-04 14:33:59 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 14:42:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 14:42:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 25
ERROR - 2019-09-04 14:44:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 63
ERROR - 2019-09-04 14:44:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 63
ERROR - 2019-09-04 14:44:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 14:44:59 --> Severity: Notice --> Undefined property: Login::$login_model C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 29
ERROR - 2019-09-04 14:44:59 --> Severity: error --> Exception: Call to a member function check_login() on null C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 29
ERROR - 2019-09-04 14:45:06 --> Severity: error --> Exception: Call to undefined method Login_model::check_login() C:\xampp\htdocs\payroll\hr\application\controllers\Login.php 29
ERROR - 2019-09-04 14:46:20 --> Query error: Table 'payrolldb.tbladmin' doesn't exist - Invalid query: SELECT *
FROM `tbladmin`
WHERE `EmailAddress` = 'siya@yopmail.com'
AND `password` = '25d55ad283aa400af464c76d713c07ad'
ERROR - 2019-09-04 14:46:45 --> Severity: Notice --> Undefined index: Admin_Type C:\xampp\htdocs\payroll\hr\application\models\Login_model.php 186
ERROR - 2019-09-04 15:03:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 15:03:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 15:04:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 15:08:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-04 15:10:07 --> 404 Page Not Found: Assets/img
