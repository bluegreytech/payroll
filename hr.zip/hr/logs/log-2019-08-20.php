<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-20 07:50:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 07:50:49 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-20 07:51:24 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-20 07:51:30 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 07:51:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 07:52:02 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:52:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:52:10 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:53:05 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:53:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:54:46 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:54:46 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:54:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:55:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:55:21 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:55:21 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:55:25 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 07:55:25 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 07:55:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-20 07:55:25 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 07:55:49 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:56:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:56:23 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:56:23 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:56:23 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 07:56:23 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 07:56:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 07:56:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-20 07:56:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:56:37 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:56:37 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:56:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 07:56:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:56:45 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:56:45 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:56:45 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 07:56:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:56:48 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:56:48 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 07:56:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:56:59 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:56:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 07:59:01 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:59:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 07:59:04 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 07:59:04 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:01:11 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:01:11 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:05:11 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:05:11 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:09:36 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:09:36 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:09:59 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:09:59 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:15:55 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:15:56 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:15:56 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:17:09 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:17:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:17:09 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:17:09 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:17:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:17:16 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:17:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:17:16 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:17:16 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:18:02 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:18:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:18:02 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:18:02 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:18:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:19:23 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:19:23 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:19:23 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:21:24 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:21:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:21:24 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:21:24 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:21:50 --> Severity: Notice --> Undefined variable: countryData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:21:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 177
ERROR - 2019-08-20 08:21:50 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:21:50 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:23:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 199
ERROR - 2019-08-20 08:23:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 199
ERROR - 2019-08-20 08:24:10 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:24:10 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:24:45 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:24:45 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:25:16 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:25:16 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:25:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:28:42 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:28:42 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:28:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:29:14 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:29:14 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:29:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:29:36 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:29:36 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:29:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:36:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 08:36:36 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:36:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 08:36:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 08:36:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 08:36:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 08:36:45 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:36:45 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:36:45 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:38:24 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:38:24 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:38:24 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:38:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:39:13 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:39:13 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:39:13 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:39:17 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:39:17 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:39:17 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:39:17 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:41:00 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:41:00 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:00 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:41:18 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:41:18 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:18 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 08:41:20 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:20 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:41:20 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 08:41:20 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 08:41:20 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 08:44:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 08:44:29 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:29 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:50 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:44:50 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:50 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:55 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:44:55 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:44:55 --> 404 Page Not Found: Upload/UserProfile
ERROR - 2019-08-20 08:49:54 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:50:32 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:50:42 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:53:00 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 93
ERROR - 2019-08-20 08:53:55 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:54:32 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:55:42 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:56:05 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:56:28 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 08:56:44 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:06:05 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:07:24 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:07:26 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:07:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 09:08:53 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:12:13 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:20:51 --> Severity: Notice --> Undefined property: Adminmaster::$mymodel C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 20
ERROR - 2019-08-20 09:20:51 --> Severity: error --> Exception: Call to a member function search() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 20
ERROR - 2019-08-20 09:21:09 --> Query error: Unknown column 'Mitesh' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `Mitesh` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:25:48 --> Query error: Unknown column 'Himesh' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName` LIKE '%%' ESCAPE '!'
AND  `Himesh` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:26:22 --> Query error: Unknown column 'Himesh' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName` LIKE '%%' ESCAPE '!'
AND  `Himesh` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:31:38 --> Query error: Unknown column 'Himesh' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName` LIKE '%%' ESCAPE '!'
AND  `Himesh` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:32:12 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%%' ESCAPE '!'
AND  `keyword2` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:32:40 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%%' ESCAPE '!'
AND  `keyword2` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:32:47 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:32:58 --> 404 Page Not Found: Search/search_keyword
ERROR - 2019-08-20 09:33:43 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:33:47 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%FirstName%' ESCAPE '!'
AND  `keyword2` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:34:20 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%FirstName%' ESCAPE '!'
AND  `keyword2` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:36:30 --> Query error: Unknown column 'keyword2' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName` LIKE '%%' ESCAPE '!'
AND  `keyword2` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:37:12 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:39:04 --> Query error: Unknown column 'keyword2' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName` LIKE '%FirstName%' ESCAPE '!'
AND  `keyword2` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:41:39 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `name` LIKE '%%' ESCAPE '!'
AND  `name` LIKE '%%' ESCAPE '!'
ERROR - 2019-08-20 09:41:45 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:41:49 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `name` LIKE '%FirstName%' ESCAPE '!'
AND  `name` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:42:21 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%FirstName%' ESCAPE '!'
AND  `keyword2` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:43:49 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:43:52 --> Query error: Unknown column 'keyword1' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `keyword1` LIKE '%FirstName%' ESCAPE '!'
OR  `keyword2` LIKE '%Himesh%' ESCAPE '!'
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: keyword C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 22
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 114
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 119
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 123
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:51:48 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 138
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: keyword C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 22
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 114
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 119
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 123
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:53:40 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 138
ERROR - 2019-08-20 09:53:44 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: keyword C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 22
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 114
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 119
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 123
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:53:46 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 138
ERROR - 2019-08-20 09:54:32 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 114
ERROR - 2019-08-20 09:54:32 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 119
ERROR - 2019-08-20 09:54:32 --> Severity: Notice --> Undefined variable: option C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 123
ERROR - 2019-08-20 09:54:32 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:54:32 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 138
ERROR - 2019-08-20 09:55:09 --> Severity: Notice --> Undefined variable: keyword C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 117
ERROR - 2019-08-20 09:55:09 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:55:09 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 138
ERROR - 2019-08-20 09:56:40 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:56:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 09:56:44 --> Severity: Notice --> Undefined variable: type C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 128
ERROR - 2019-08-20 09:58:09 --> Severity: Notice --> Undefined variable: adminmasterData C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 85
ERROR - 2019-08-20 09:58:09 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 09:58:09 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 10:00:35 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:00:42 --> 404 Page Not Found: Adminmaster/search_keyword
ERROR - 2019-08-20 10:01:05 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:01:08 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:03:52 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:03:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:03:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:03:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:03:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:03:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 35
ERROR - 2019-08-20 10:04:08 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:04:28 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:05:34 --> Severity: error --> Exception: Too few arguments to function Adminmaster_model::search(), 1 passed in C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php on line 22 and exactly 2 expected C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 106
ERROR - 2019-08-20 10:06:21 --> Severity: error --> Exception: Too few arguments to function Adminmaster_model::search(), 1 passed in C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php on line 22 and exactly 2 expected C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 106
ERROR - 2019-08-20 10:06:25 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:06:57 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:06:57 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 10:07:01 --> Severity: error --> Exception: Too few arguments to function Adminmaster_model::search(), 1 passed in C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php on line 22 and exactly 2 expected C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 106
ERROR - 2019-08-20 10:08:57 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:08:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:08:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:08:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:08:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:43:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:43:49 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-20 10:44:08 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:44:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:44:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:44:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:44:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 10:44:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:44:31 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:44:48 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:46:44 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:46:49 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:47:03 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:47:54 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:48:10 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:49:12 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:49:18 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:49:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:49:38 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:52:19 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:52:22 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:52:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '".LastName LIKE '%Himesh shah%' ESCAPE '!'
ORDER BY `UserId` DESC' at line 3 - Invalid query: SELECT *
FROM `tbluser`
WHERE `FirstName`.`"` ".LastName LIKE '%Himesh shah%' ESCAPE '!'
ORDER BY `UserId` DESC
ERROR - 2019-08-20 10:53:02 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:53:15 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:55:22 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 10:59:07 --> Severity: error --> Exception: syntax error, unexpected '',LastName) as FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 111
ERROR - 2019-08-20 11:00:20 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:01:05 --> Severity: error --> Exception: syntax error, unexpected '',LastName) as FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:04:29 --> Severity: error --> Exception: syntax error, unexpected '',LastName) as FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:04:35 --> Severity: error --> Exception: syntax error, unexpected '',LastName) as FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:04:59 --> Severity: error --> Exception: syntax error, unexpected ''.LastName) as FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:07:35 --> Severity: error --> Exception: syntax error, unexpected '', FirstName, LastName) AS Fir' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:07:54 --> Severity: error --> Exception: syntax error, unexpected '', FirstName, LastName) AS Fir' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:09:46 --> Severity: error --> Exception: syntax error, unexpected '', FirstName, LastName) AS Fir' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:09:49 --> Severity: error --> Exception: syntax error, unexpected '', FirstName, LastName) AS Fir' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:11:25 --> Severity: error --> Exception: syntax error, unexpected '', FirstName, LastName) AS Fir' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:12:13 --> Severity: error --> Exception: syntax error, unexpected '',FirstName,LastName) AS First' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:12:51 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 84
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 106
ERROR - 2019-08-20 11:13:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:13 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$ProfileImage C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 94
ERROR - 2019-08-20 11:13:33 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:13:33 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:14:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:14:06 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:14:34 --> Severity: error --> Exception: syntax error, unexpected '',FirstName,LastName) AS First' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:15:08 --> Severity: error --> Exception: syntax error, unexpected '',LastName) AS FirstName,Email' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:15:31 --> Severity: error --> Exception: syntax error, unexpected ''LastName) AS FirstName,EmailA' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 83
ERROR - 2019-08-20 11:16:30 --> Query error: Incorrect parameters in the call to native function 'CONCAT' - Invalid query: SELECT `UserId`, `RoleId`, CONCAT(FirstName LastName) AS FirstName, `EmailAddress`, `DateofBirth`, `PhoneNumber`, `ProfileImage`, `Gender`, `Address`, `PinCode`, `CountryId`, `StateId`, `City`, `IsActive`
FROM `tbluser`
ORDER BY `UserId` DESC
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:05 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:17:05 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:17:22 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:17:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:17:51 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:18:20 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:40 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:18:40 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:18:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:18:52 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:18:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:18:58 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:19:19 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:19:19 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:06 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:20:06 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:20:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:20:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:13 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:13 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:44 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:44 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:21:57 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:21:57 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:22:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:22:50 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:32 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:24:32 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:49 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:24:50 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:24:50 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:25:04 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 11:25:04 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 11:25:04 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:26:09 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:26:09 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:26:09 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 11:26:10 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 11:26:10 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 11:26:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:27:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:27:53 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:04 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:04 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:51 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:56 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:56 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:56 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:56 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:28:56 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:28:56 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:28:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:29:00 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:29:00 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:00 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:00 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:29:01 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:29:01 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:16 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:30:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:23 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:30:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:30:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:30:56 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:31:39 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:31:39 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:32:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:32:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:28 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:28 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:34:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:34:34 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:34:34 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:37 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:37 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:38 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:35:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:35:47 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:35:48 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:36:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:36:53 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:37:16 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:37:16 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:38:55 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:38:55 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:07 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:40:07 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:40:27 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:40:27 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:40:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:42:17 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:42:17 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:42:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:44:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:44:12 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:45:23 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:45:23 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:45:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:45:40 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:45:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:46:48 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:46:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:48:18 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:48:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 99
ERROR - 2019-08-20 11:48:22 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\Dashboard\adminlist.php 107
ERROR - 2019-08-20 11:48:22 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:48:51 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:48:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:49:36 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:49:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:49:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:50:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:50:56 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:50:56 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:52:25 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:52:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:52:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:54:01 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:01 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:54:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:54:26 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:54:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:54:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:57:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:57:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:57:59 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:57:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:57:59 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:00 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:00 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:00 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:00 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:10 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:10 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:58:23 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 924
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 11:59:25 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 11:59:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:00:37 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:00:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:12 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:21 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 930
ERROR - 2019-08-20 12:01:54 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:01:54 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:01:57 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:01:58 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:02:11 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:02:11 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:02:11 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:02:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:02:11 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:02:13 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:02:16 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:03:35 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:03:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:04:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:04:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:04:36 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:04:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:04:46 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:04:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:04:46 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:05:18 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:05:19 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:05:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:05:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:05:50 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:05:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:05:54 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:05:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:05:54 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:07:33 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:07:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:07:33 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:07:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:07:38 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:07:38 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:07:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:08:37 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:08:37 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:08:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:08:37 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:09:22 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:09:22 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:09:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:09:24 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:09:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:09:24 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:09:24 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 12:09:43 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:09:43 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:09:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:43:34 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 12:57:22 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-20 12:57:26 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:57:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 12:57:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 12:57:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 12:57:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 12:57:30 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:57:30 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:57:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 12:58:35 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\Dashboard\profile.php 918
ERROR - 2019-08-20 12:58:35 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 12:58:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:06:31 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:06:31 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 13:06:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:06:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:06:35 --> 404 Page Not Found: Upload/default
ERROR - 2019-08-20 13:08:24 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:08:26 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:08:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:08:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:15:46 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 41
ERROR - 2019-08-20 13:18:57 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 46
ERROR - 2019-08-20 13:19:00 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 46
ERROR - 2019-08-20 13:19:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:19:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:19:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:19:04 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:20:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:20:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:20:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:20:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 13:20:07 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:20:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:20:22 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:20:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:24:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:24:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:24:15 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:24:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:24:29 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:24:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:24:32 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:24:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:29:05 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:29:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:29:06 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 13:29:12 --> The upload path does not appear to be valid.
ERROR - 2019-08-20 13:29:12 --> Severity: Notice --> Undefined variable: filename C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 232
ERROR - 2019-08-20 13:32:04 --> The upload path does not appear to be valid.
ERROR - 2019-08-20 13:32:04 --> Severity: Notice --> Undefined variable: filename C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 222
ERROR - 2019-08-20 13:32:06 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:32:07 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:32:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:32:15 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:32:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:32:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 13:32:27 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 13:32:27 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 13:32:27 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-20 13:32:27 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 13:33:12 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:33:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:33:13 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 13:33:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 13:33:21 --> 404 Page Not Found: Default/js
ERROR - 2019-08-20 13:33:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-20 13:33:21 --> 404 Page Not Found: Default/css
ERROR - 2019-08-20 13:39:13 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:39:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:39:22 --> The upload path does not appear to be valid.
ERROR - 2019-08-20 13:39:22 --> Severity: Notice --> Undefined variable: filename C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 222
ERROR - 2019-08-20 13:40:47 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:40:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 13:40:49 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:40:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:42:03 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:42:05 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:42:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:42:40 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:42:42 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:42:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:42:50 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:42:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:41 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:46:43 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:46:54 --> Severity: Notice --> Undefined variable: City C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 918
ERROR - 2019-08-20 13:46:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:02 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:47:30 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:48:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:48:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:51 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:52 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:48:53 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:48:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:12 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 99
ERROR - 2019-08-20 13:49:58 --> Severity: Notice --> Undefined property: stdClass::$LastName C:\xampps\htdocs\payroll\admin\application\views\dashboard\adminlist.php 107
ERROR - 2019-08-20 13:50:53 --> The upload path does not appear to be valid.
ERROR - 2019-08-20 13:50:53 --> Severity: Notice --> Undefined variable: filename C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 33
ERROR - 2019-08-20 13:53:43 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 25
ERROR - 2019-08-20 13:55:22 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 25
ERROR - 2019-08-20 14:24:59 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 25
