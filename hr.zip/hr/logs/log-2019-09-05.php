ERROR - 2019-09-05 12:57:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 12:59:54 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 12:59:54 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 12:59:54 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 12:59:54 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 12:59:54 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 12:59:54 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 12:59:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 12:59:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:01:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:01:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:10:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:10:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:10:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:10:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:11:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:11:55 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:12:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:12:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:17:36 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:17:36 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:17:36 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:20:05 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:20:12 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:20:12 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:20:30 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:20:30 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:30 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:20:38 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:20:38 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:20:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:21:02 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 13:21:02 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 13:21:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:21:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:05 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:57 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:21:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:01 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:02 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:22:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:22:51 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:23:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:23:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:23:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:23:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:23:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:23:08 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:23:08 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:23:08 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:08 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:08 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:08 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:24 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:23:24 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:23:24 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:24 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:24 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:24 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:23:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:28:36 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:28:36 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:28:36 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:28:36 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:28:36 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:28:36 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:28:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:29:37 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:29:37 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:29:37 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:29:37 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:29:37 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:29:37 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:29:41 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:29:45 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 307
ERROR - 2019-09-05 13:29:45 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 308
ERROR - 2019-09-05 13:29:45 --> Severity: Notice --> Trying to get property 'comemailaddress' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 309
ERROR - 2019-09-05 13:29:45 --> Severity: Notice --> Trying to get property 'comcontactnumber' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 310
ERROR - 2019-09-05 13:29:45 --> Severity: Notice --> Trying to get property 'gstnumber' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 311
ERROR - 2019-09-05 13:29:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:29:50 --> Severity: Notice --> Trying to get property 'companyid' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 307
ERROR - 2019-09-05 13:29:50 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 308
ERROR - 2019-09-05 13:29:50 --> Severity: Notice --> Trying to get property 'comemailaddress' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 309
ERROR - 2019-09-05 13:29:50 --> Severity: Notice --> Trying to get property 'comcontactnumber' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 310
ERROR - 2019-09-05 13:29:50 --> Severity: Notice --> Trying to get property 'gstnumber' of non-object C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 311
ERROR - 2019-09-05 13:33:29 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:33:29 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:33:29 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:33:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 13:33:53 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:33:53 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:33:53 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:33:53 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:33:53 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:33:53 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:33:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:34:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:34:48 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 13:34:48 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 13:34:48 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:34:48 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:34:48 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:34:48 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 13:34:49 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:35:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:35:03 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:35:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:37:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:37:05 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:37:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:37:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:39:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:39:08 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:46:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:46:15 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:46:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:46:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:47:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:47:02 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:47:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:47:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:51:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:51:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:54:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:54:20 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:54:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:54:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:55:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:55:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 13:59:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 13:59:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:48 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:51 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:00:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:00:58 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:00:58 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:00:58 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:00:58 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:01:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:01:06 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:01:06 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:01:07 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:01:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:01:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:01:07 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:01:08 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:01:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:01:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:01:08 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:02:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:02:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:02:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:46 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:02:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:02:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:02:47 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:02:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:02:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:49 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:02:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:55 --> Query error: Unknown column 't1.UserId' in 'field list' - Invalid query: SELECT `t1`.`UserId`, `t1`.`RoleId`, `t1`.`FirstName`, `t1`.`LastName`, `t1`.`EmailAddress`, `t1`.`DateofBirth`, `t1`.`PhoneNumber`, `t1`.`Gender`, `t1`.`ProfileImage`, `t1`.`Address`, `t1`.`PinCode`, `t1`.`CountryId`, `t1`.`StateId`, `t1`.`City`, `t1`.`IsActive`, `t2`.*, `t3`.*
FROM `tbluser` as `t1`
LEFT JOIN `tblhr` as `t2` ON `t1`.`UserId` = `t2`.`UserId`
LEFT JOIN `tblcompany` as `t3` ON `t2`.`companyid` = `t3`.`companyid`
WHERE `RoleId` = 3
ERROR - 2019-09-05 14:02:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:02:58 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:02:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:02:59 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:07 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:03:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:08 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:17 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 14:03:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:18 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:03:18 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:03:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:03:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:04:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:04:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:04:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:04:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:04:50 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:06:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:06:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:06:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:06:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:06:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:06:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:07:36 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:08:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:08:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:08:35 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:08:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:08:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:08:35 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:09:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:09:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:09:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:09:38 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:09:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:09:38 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:09:38 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:10:01 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:10:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:10:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:10:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:10:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:10:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:11:12 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:15:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:15:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:15:31 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:15:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:15:31 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:15:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:11 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:16:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:16:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:16:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:16:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:16:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:16:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:16:34 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:16:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:34 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:16:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:18:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:18:47 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:18:48 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:18:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:18:48 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:18:48 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:30:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:30:59 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:31:00 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:31:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:31:00 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:31:00 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:31:04 --> Severity: Notice --> Undefined variable: complianceData C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 72
ERROR - 2019-09-05 14:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 72
ERROR - 2019-09-05 14:31:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:31:04 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:31:05 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:31:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:31:05 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:31:05 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:34:28 --> Severity: Notice --> Undefined property: stdClass::$complianceData C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 315
ERROR - 2019-09-05 14:36:41 --> Severity: Notice --> Undefined property: stdClass::$complianceData C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 315
ERROR - 2019-09-05 14:44:17 --> Severity: Notice --> Undefined variable: complianceData C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 72
ERROR - 2019-09-05 14:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 72
ERROR - 2019-09-05 14:44:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:44:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:44:17 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:44:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:44:18 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:44:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:51:05 --> Severity: Notice --> Undefined variable: d C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 321
ERROR - 2019-09-05 14:51:05 --> Severity: Notice --> Undefined variable: d C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 321
ERROR - 2019-09-05 14:51:05 --> Severity: Notice --> Undefined variable: d C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 321
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 76
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:52:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:52:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:52:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:52:52 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:52:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:52:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:52:52 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:53:16 --> Severity: Notice --> Undefined variable: comdata C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 73
ERROR - 2019-09-05 14:53:16 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:53:16 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:53:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:53:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:54:50 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:54:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:54:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:54:50 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:54:50 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:54:51 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:54:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:57:28 --> Severity: Notice --> Undefined variable: com_compliances C:\xampp\htdocs\payroll\hr\application\controllers\Home.php 324
ERROR - 2019-09-05 14:58:28 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:58:28 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:58:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:58:38 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 77
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:44 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 80
ERROR - 2019-09-05 14:58:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:58:44 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:58:44 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:58:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:58:44 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:58:45 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:58:58 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:58:58 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:23 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:59:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:59:24 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:59:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:24 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 74
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 74
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 74
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:34 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:35 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancename' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 78
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'compliancepercentage' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 79
ERROR - 2019-09-05 14:59:51 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 14:59:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 14:59:52 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 14:59:52 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 14:59:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:52 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 14:59:52 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 15:00:45 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 15:00:45 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 15:00:45 --> Severity: Notice --> Trying to get property 'complianceid' of non-object C:\xampp\htdocs\payroll\hr\application\views\common\company_setting.php 81
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:00:46 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:01:11 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 15:01:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:01:21 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:01:21 --> 404 Page Not Found: Default/css
ERROR - 2019-09-05 15:01:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:01:21 --> 404 Page Not Found: Default/js
ERROR - 2019-09-05 15:01:21 --> 404 Page Not Found: Default/plugins
ERROR - 2019-09-05 15:01:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:01:33 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:01:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:01:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:01:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:01:53 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:02:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:02:10 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:02:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:02:40 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:06:21 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 15:06:21 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 15:06:21 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:21 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:21 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:21 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:21 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:22 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:22 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:22 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:22 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:22 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 158
ERROR - 2019-09-05 15:06:33 --> Severity: Notice --> Undefined variable: UserId C:\xampp\htdocs\payroll\hr\application\views\Leave\leaves.php 473
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:33 --> 404 Page Not Found: Leave/assets
ERROR - 2019-09-05 15:06:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-09-05 15:12:06 --> Severity: Notice --> Undefined variable: companyData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 30
ERROR - 2019-09-05 15:12:06 --> Severity: Notice --> Undefined variable: hrData C:\xampp\htdocs\payroll\hr\application\views\dashboard\dashboard.php 39
ERROR - 2019-09-05 15:12:06 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 15:12:06 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 15:12:06 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 15:12:06 --> 404 Page Not Found: Home/assets
ERROR - 2019-09-05 15:12:19 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:12:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:12:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:12:21 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:12:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:12:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:12:23 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:13:32 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:13:34 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:14:16 --> Severity: Notice --> Trying to get property 'companyname' of non-object C:\xampp\htdocs\payroll\hr\application\helpers\custom_helper.php 861
ERROR - 2019-09-05 15:14:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:14:31 --> 404 Page Not Found: Default/assets
ERROR - 2019-09-05 15:15:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:15:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:16:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-09-05 15:17:40 --> 404 Page Not Found: Home/index.php
