<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:09:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:09:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 330
ERROR - 2019-08-13 06:14:08 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 342
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Adminmaster/assets
ERROR - 2019-08-13 06:14:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 330
ERROR - 2019-08-13 06:14:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 342
ERROR - 2019-08-13 06:14:12 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 330
ERROR - 2019-08-13 06:14:12 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\header.php 342
ERROR - 2019-08-13 06:14:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:12 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:14:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:15:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:15:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:15:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:15:57 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:15:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:15:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:15:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:15:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:15:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:15:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:15:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:15:58 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 36
ERROR - 2019-08-13 06:17:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:17:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:17:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:17:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:17:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:17:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:18:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:18:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:18:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:02 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 48
ERROR - 2019-08-13 06:20:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:20:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:20:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:55 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:20:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:20:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:22:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:22:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:22:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:23:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:23:27 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:23:27 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:24:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:24:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:24:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:24:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:25:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:25:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:25:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:28:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:28:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:28:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:30:46 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:46 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:30:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 06:30:51 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 06:30:51 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:30:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 06:31:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 06:31:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:31:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:34:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:34:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:34:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:34:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:34:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:34:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:35:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:35:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:35:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:36:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:36:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:36:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:37:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:37:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:37:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:37:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:37:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:37:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:42:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:42:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:42:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:43:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:43:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:43:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:45:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:45:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:45:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:45:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:51:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:51:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:51:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:52:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 06:52:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 06:52:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:02:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:02:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:02:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:02:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:02:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:02:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:04:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:04:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:04:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:10:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:10:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:10:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:18:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:18:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:18:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:19:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:19 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:19:19 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:19 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:19:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:19:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:22:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:51 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:22:51 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:51 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:22:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:22:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:26:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:26:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:26:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:28:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:28:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:28:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:29:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:29:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:29:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:31:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:31:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_general.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:32:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:32:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:32:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:33:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:33:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:33:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:33:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:33:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:33:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:34:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:34:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:34:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:35:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:35:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:35:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:37:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:37:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 07:37:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 07:37:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 07:37:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 07:37:54 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:37:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:38:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:38:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:38:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:38:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:38:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:38:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:46:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:46:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:46:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:46:56 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:47:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:47:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:47:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:47:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:47:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:47:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:48:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:48:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:48:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:48:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:49:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:49:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:49:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:53:45 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 63
ERROR - 2019-08-13 07:53:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:53:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:53:47 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 63
ERROR - 2019-08-13 07:53:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:53:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:53:49 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 63
ERROR - 2019-08-13 07:53:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:53:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:54:24 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 63
ERROR - 2019-08-13 07:54:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:54:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:54:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:54:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:54:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:55:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:55:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:56:26 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 64
ERROR - 2019-08-13 07:56:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:28 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 64
ERROR - 2019-08-13 07:56:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:29 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampps\htdocs\payroll\admin\application\models\Adminmaster_model.php 64
ERROR - 2019-08-13 07:56:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 07:56:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 07:56:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 07:56:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:06:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:06:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:06:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:33 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:07:33 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:33 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:07:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:07:59 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:07:59 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:07:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:15:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:53 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:15:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:15:54 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:15:54 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:15:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:30 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:17:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:17:31 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:17:31 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:18:37 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:18:38 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:25:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:25:44 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:25:44 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:25:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:26:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:14 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 08:26:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:26:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:26:25 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:26:25 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:26:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:29:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:23 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:29:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:29:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:29:47 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:29:47 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:29:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:32:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:10 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:32:11 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:32:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:36:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:36:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:36:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:37:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:37:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:37:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:37:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:39:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:39:55 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 08:39:55 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:39:55 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:46:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:46:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:46:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:47:20 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:47:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:47:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:47:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:47:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:47:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:11 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:58:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:58:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:58:46 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:58:46 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:59:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 08:59:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 08:59:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:01:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:21 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:01:21 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:21 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:01:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:01:30 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:01:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:01:30 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:01:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:02:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:02:15 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:02:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:02:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:03:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:24 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:03:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:03:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:27 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:03:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:03:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:03:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:03:45 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:03:45 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:03:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:04:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:06 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:04:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:07 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:04:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:36 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:04:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:55 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:04:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:57 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:04:57 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:04:57 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:04:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:05:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:05:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:05:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:07:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:07:12 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:07:12 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:07:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:12 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:07:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:07:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:10:36 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:10:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:11:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:11:22 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:11:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:11:24 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:11:24 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:11:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:13:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:13:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:13:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:13:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:13:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:13:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:14:20 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:14:20 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:20 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:14:53 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:14:53 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:14:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:21:05 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:21:05 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:21:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:21:22 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:21:22 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:21:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:22:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:22:07 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:22:07 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:22:07 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:30 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:41 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:24:41 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:24:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:25:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:25:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:25:15 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:25:15 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:25:32 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:25:32 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:25:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:42 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:42 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:43 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:26:43 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:57 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:26:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:26:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:58 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:26:58 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:26:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:28:28 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:28:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:32:39 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:32:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:35:26 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:35:26 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:35:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:36:34 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:36:34 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:36:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:37:18 --> 404 Page Not Found: Default/js
ERROR - 2019-08-13 09:37:18 --> 404 Page Not Found: Default/css
ERROR - 2019-08-13 09:37:18 --> 404 Page Not Found: Default/plugins
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:37:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:40:18 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:40:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:40:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:40:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:40:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:40:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:42:54 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:42:54 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:42:54 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:45:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:45:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:45:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:48:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:48:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:48:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:48:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:48:27 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:48:27 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:52:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:52:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:52:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:53:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:34 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:53:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:52 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 09:53:52 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 09:53:52 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:44:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 10:44:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:44:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:52:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 10:52:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:52:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:59:40 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 10:59:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 10:59:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:00:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:00:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:00:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:00:48 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:00:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:00:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:01:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:01:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:01:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:02:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:02:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:02:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:02:32 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:02:32 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:02:32 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:03:13 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:03:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:03:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:03:26 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:03:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:03:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:03:48 --> Severity: error --> Exception: Too few arguments to function Adminmaster::admin_master_profile(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 16
ERROR - 2019-08-13 11:03:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:03:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:10:53 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 893
ERROR - 2019-08-13 11:10:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:10:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:09 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 893
ERROR - 2019-08-13 11:11:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:10 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 893
ERROR - 2019-08-13 11:11:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:12 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 893
ERROR - 2019-08-13 11:11:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:39 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampps\htdocs\payroll\admin\application\views\dashboard\profile.php 893
ERROR - 2019-08-13 11:11:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:11:47 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:11:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:11:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:13:58 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:13:58 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:13:58 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:15:02 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:15:02 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:15:02 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:16:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:16:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:16:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:19:59 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:19:59 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:19:59 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:34:38 --> Severity: error --> Exception: Too few arguments to function Login::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 106
ERROR - 2019-08-13 11:34:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:34:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:35:18 --> Severity: error --> Exception: Too few arguments to function Login::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 106
ERROR - 2019-08-13 11:35:18 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:35:18 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:36:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:36:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:07 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:07 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:11 --> Severity: error --> Exception: Too few arguments to function Login::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 106
ERROR - 2019-08-13 11:37:11 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:37:11 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:37:13 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:50 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:50 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:37:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:37:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:37:58 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:37:58 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:38:43 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:38:43 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:38:47 --> Severity: error --> Exception: Too few arguments to function Login::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 106
ERROR - 2019-08-13 11:38:47 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:38:47 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:38:58 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:38:58 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:01 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:01 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:05 --> Severity: error --> Exception: Too few arguments to function Login::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 106
ERROR - 2019-08-13 11:40:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:40:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 11:40:08 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:40:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:40:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:55 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:40:55 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:40:55 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:40:55 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:41:31 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:41:31 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:41:31 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:41:31 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:42:19 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:42:19 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:42:19 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:42:19 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:43:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:43:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:43:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:43:34 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:43:51 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:43:51 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:43:52 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:43:52 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:44:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:44:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:44:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:44:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:48:32 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:48:32 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:48:32 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:48:32 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:49:33 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:49:33 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:49:33 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:49:33 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:09 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:09 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:09 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:09 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:10 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:48 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:48 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:51:48 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:51:48 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:52:17 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:52:17 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:52:17 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:52:17 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:52:53 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:52:53 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:52:53 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:52:53 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:52:56 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:52:56 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:52:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:53:22 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:53:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:53:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:53:24 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:24 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:24 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:24 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:26 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:26 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:26 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:26 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:27 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:27 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:27 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:27 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 11:53:35 --> Severity: Notice --> Undefined variable: UserId C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 60
ERROR - 2019-08-13 11:54:44 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:54:44 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:54:44 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:54:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:54:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:54:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:55:00 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:55:00 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:55:00 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 11:57:16 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 11:57:16 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:16 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:16 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 34
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 55
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 67
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: EmailAddress C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 71
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 75
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 79
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 821
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 843
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 849
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 854
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 870
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 898
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 917
ERROR - 2019-08-13 11:57:17 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 923
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 58
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 80
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 86
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 91
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 107
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 135
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 154
ERROR - 2019-08-13 12:17:53 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 160
ERROR - 2019-08-13 12:17:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:17:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:17:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 99
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 127
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 146
ERROR - 2019-08-13 12:18:38 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 152
ERROR - 2019-08-13 12:18:38 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:18:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:18:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 99
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 127
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 146
ERROR - 2019-08-13 12:19:15 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 152
ERROR - 2019-08-13 12:19:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:19:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:19:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 99
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 127
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 146
ERROR - 2019-08-13 12:19:49 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 152
ERROR - 2019-08-13 12:19:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:19:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:19:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:04 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:20:04 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:20:04 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:20:04 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:20:04 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 99
ERROR - 2019-08-13 12:20:05 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 127
ERROR - 2019-08-13 12:20:05 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 146
ERROR - 2019-08-13 12:20:05 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 152
ERROR - 2019-08-13 12:20:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:20:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: Gender C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 99
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 127
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 146
ERROR - 2019-08-13 12:20:10 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 152
ERROR - 2019-08-13 12:20:10 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:20:10 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:10 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 110
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 129
ERROR - 2019-08-13 12:20:49 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 135
ERROR - 2019-08-13 12:20:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:20:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:20:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 110
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 129
ERROR - 2019-08-13 12:21:24 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 135
ERROR - 2019-08-13 12:21:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:21:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:21:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: ProfileImage C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 50
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 72
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 78
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 83
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 110
ERROR - 2019-08-13 12:22:07 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 129
ERROR - 2019-08-13 12:22:08 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 135
ERROR - 2019-08-13 12:22:08 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:22:08 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:22:08 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: FirstName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 53
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: LastName C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 59
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: DateofBirth C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 64
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: Address C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 91
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 98
ERROR - 2019-08-13 12:22:25 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 104
ERROR - 2019-08-13 12:22:25 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:22:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:22:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:23:29 --> Severity: Notice --> Undefined variable: PinCode C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 57
ERROR - 2019-08-13 12:23:29 --> Severity: Notice --> Undefined variable: PhoneNumber C:\xampps\htdocs\payroll\admin\application\views\common\changepassword.php 63
ERROR - 2019-08-13 12:23:29 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:23:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:23:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:26:14 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:26:14 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:26:14 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:27:39 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:27:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:27:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:27:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:27:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:27:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:09 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:28:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:28:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:28:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:28:37 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 77
ERROR - 2019-08-13 12:28:38 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 77
ERROR - 2019-08-13 12:28:38 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:28:38 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:29:42 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 77
ERROR - 2019-08-13 12:29:42 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 77
ERROR - 2019-08-13 12:29:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:29:43 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:29:46 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:29:46 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:29:46 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:30:15 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:30:15 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:30:15 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:31:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:31:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:31:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:31:09 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:31:09 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:31:09 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:31:09 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:34:22 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:34:22 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:34:22 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:34:22 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:35:27 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:35:27 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:35:27 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:35:34 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:35:34 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:35:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:35:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:37:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:37:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:37:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:37:39 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:37:39 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:37:39 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:37:39 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:40:03 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:40:03 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:03 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:40:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:40:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:05 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:40:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:06 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:40:06 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:40:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:49:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:49:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:49:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:54:35 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:54:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:54:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:54:37 --> Severity: error --> Exception: Too few arguments to function Adminmaster::change_password(), 0 passed in C:\xampps\htdocs\payroll\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 68
ERROR - 2019-08-13 12:54:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:54:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:55:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:55:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:55:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:55:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:55:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:55:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:55:41 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:55:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:55:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:01 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:56:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:12 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:56:12 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:12 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> 404 Page Not Found: Login/assets
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Notice --> Undefined variable: session C:\xampps\htdocs\payroll\admin\application\controllers\Login.php 42
ERROR - 2019-08-13 12:56:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:25 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 12:56:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 12:56:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 12:56:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 12:56:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 12:56:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:35 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:37 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:56:37 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:37 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:41 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:56:41 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 12:56:41 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:56:41 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 12:56:45 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 12:56:45 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 12:56:45 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:05 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:52:05 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:06 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:28 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:52:29 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:29 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:50 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:52:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:52:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:55:48 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:55:48 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:55:48 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:55:48 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:56:04 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:56:04 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:04 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:13 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:56:13 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:56:13 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:56:13 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:56:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:56:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 13:56:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 13:56:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:40 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:42 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:56:42 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:56:42 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:58:49 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:58:49 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:58:49 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:58:50 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:58:50 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:58:50 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:58:50 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:58:53 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 13:58:53 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:58:53 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 13:59:01 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:59:01 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 13:59:01 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 13:59:01 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 14:00:17 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:00:17 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:00:17 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:01:57 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 14:01:57 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 14:01:57 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 14:01:57 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 14:02:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:02:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:24 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:26 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 14:02:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 14:02:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:28 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:30 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:02:30 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:30 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:02:34 --> Severity: Notice --> Undefined property: Adminmaster::$Login_model C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 14:02:34 --> Severity: error --> Exception: Call to a member function changepass() on null C:\xampps\htdocs\payroll\admin\application\controllers\Adminmaster.php 78
ERROR - 2019-08-13 14:02:34 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 14:02:34 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 219
ERROR - 2019-08-13 14:03:23 --> 404 Page Not Found: Default/cdn-cgi
ERROR - 2019-08-13 14:03:23 --> Severity: Warning --> include(C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
ERROR - 2019-08-13 14:03:23 --> Severity: Warning --> include(): Failed opening 'C:\xampps\htdocs\payroll\admin\application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampps\php\PEAR') C:\xampps\htdocs\payroll\admin\system\core\Exceptions.php 182
